package com.recipe.api.config;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ReceiptInterceptor extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		log.info("This is Pre Handle ===========================");
		String x = request.getMethod();
		log.info("Request"+request.getRequestURL());
		log.info(x + "intercepted");
		return true;
	}

}
