package com.recipe.api.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

import com.recipe.api.entity.RecipeCatEntity;
import com.recipe.api.entity.RecipeEntity;

@Repository
public interface RecipeRepository extends JpaRepository<RecipeEntity, String> {

	Optional<RecipeEntity> findByName(String recipeName);

	Optional<RecipeEntity> findByImagepath(String path);

	Optional<RecipeEntity> findByRecipeid(Long recipeId);

	List<RecipeEntity> findAllByRecipeCatEntity(RecipeCatEntity recipeCatEntity);

	@Modifying
	void deleteByRecipeid(Long recepeId);

	List<RecipeEntity> findAllByName(String receipName);

	List<RecipeEntity> findAllByNameAndRecipeCatEntity(String receipName,
			RecipeCatEntity recipeCatEntity);

}
