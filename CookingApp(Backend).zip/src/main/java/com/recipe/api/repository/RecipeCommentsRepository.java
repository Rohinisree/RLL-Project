package com.recipe.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

import com.recipe.api.entity.RecipeCommentsEntity;
import com.recipe.api.entity.RecipeEntity;

@Repository
public interface RecipeCommentsRepository extends
		JpaRepository<RecipeCommentsEntity, Long> {

	List<RecipeCommentsEntity> findAllByRecipeEntity(RecipeEntity recipeEntity);

	@Modifying
	void deleteByRecipeEntity(RecipeEntity recipeEntityActual);

}
