package com.recipe.api.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

@Component
public class RecipeValidationUtils {

	public boolean checkPhoneNoRegex(String phoneNumber) {
		String regex = "\\d{10}";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(phoneNumber);
		if (matcher.matches()) {

			boolean allZero = phoneNumber.matches("0{10}");
			if (allZero) {
				return false;
			} else {
				return true;
			}
		} else {
			return false;
		}
	}

}
