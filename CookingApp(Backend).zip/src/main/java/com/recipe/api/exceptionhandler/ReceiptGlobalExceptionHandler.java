package com.recipe.api.exceptionhandler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.recipe.api.controller.BaseController;
import com.recipe.api.exception.RecipeException;
import com.recipe.api.response.AJAXResponse;

@ControllerAdvice
public class ReceiptGlobalExceptionHandler {

	@Autowired
	private BaseController baseController;

	@ExceptionHandler(RecipeException.class)
	public ResponseEntity<AJAXResponse> handleException(RecipeException e) {
		AJAXResponse ajaxResponse = new AJAXResponse();
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(
				baseController.generateErrorMessageBasedResponse(ajaxResponse,
						e.getMessage()));
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<AJAXResponse> handleInternalErrors(RecipeException e) {
		AJAXResponse ajaxResponse = new AJAXResponse();
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(
				baseController.generateErrorMessageBasedResponse(ajaxResponse,
						e.getMessage()));
	}

}
