package com.recipe.api.constants;

public interface RecipeConstants {

	//String FILE_PATH = "C:\\BACKUP_SHABNAZ_DATA\\RIGELDEVELOPMENT\\RECEIPT_DEV_PROJECT\\receiptdevpro\\src\\assets\\images\\";
	String FILE_PATH = "C:\\PROJECT\\CookingApp\\receiptdevpro\\src\\assets\\images\\";

	String LIVELINESS_MESSAGE = "Server is up and running successfully";

	String FIRSTNAME_CANNOT_BE_EMPTY = "First Name cannot be empty";

	String LASTNAME_CANNOT_BE_EMPTY = "Last Name cannot be empty";

	String USERNAME_CANNOT_BE_EMPTY = "Username cannot be empty";

	String PASSWORD_CANNOT_BE_EMPTY = "Password cannot be empty";

	String EMAIL_CANNOT_BE_EMPTY = "Email cannot be empty";

	String PHONENO_CANNOT_BE_EMPTY = "Phone no cannot be empty";

	String PHONENO_CANNOT_BE_LESS_THAN_10_OR_HIGHER_THAN_10 = "Phone Number cannot be less than 10 or higher than 10 digits";

	String PHONENO_IS_INVALID = "Phone Number is Invalid";

	String INTERNAL_ERROR_DURING_SAVE_OF_USERS_INFORMATION = "Internal Error during save of User Information";

	String DUPLICATE_USERNAME_ALREADY_EXISTS = "username already exists";

	String EMAIL_ALREADY_EXISTS = "Email already exists";

	String PHONENO_ALREADY_EXISTS = "Phone no already exists";

	String USERNAME_DOES_NOT_EXISTS_TO_UPDATE = "Username does not exists to update";

	String CANNOT_USE_THE_EMAIL = "Cannot use the email address";

	String CANNOT_USE_THE_PHONE_NUMBER = "Cannot use the Phone Number";

	String INTERNAL_ERROR_DURING_UPDATE_OF_USERS_INFORMATION = "An internal error has occurred during update of users information";

	String FETCHING_OF_USER_INFORMATION_HAS_FAILED = "Fetching of User Information has Failed";

	String USERNAME_DOES_NOT_EXISTS = "Username does not exist";

	String INVALID_CREDENTIALS = "Invalid Credentials";

	String NEW_PASSWORD_CANNOT_BE_EMPTY = "New Password Cannot be Empty";

	String OLD_PASSWORD_CANNOT_BE_EMPTY = "Old Password cannot be Empty";

	String COULD_NOT_UPDATE_PASSWORD_INFORMATION = "Could not update password information";

	String SAVE_OF_USER_IS_SUCCESSFUL = "Save of user information is successful";

	String UPDATE_OF_USER_IS_SUCCESSFUL = "Update of user is successful";

	String FETCH_OF_USER_IS_SUCCESSFUL = "Fetch of user is successful";

	String LOGIN_IS_SUCCESSFUL = "Login is successful";

	String CHANGE_PASSWORD_IS_SUCCESSFUL = "Change Password is successful";

	String FETCH_OF_RECIPE_CAT_IS_SUCCESSFUL = "Fetch of Recipe Cat is successful";

	String RECIPE_NAME_CANNOT_BE_EMPTY = "Recipe Name cannot be empty";

	String INGREDIENT_CANNOT_BE_EMPTY = "Ingredient cannot be empty";

	String STEPS_CANNOT_BE_EMPTY = "Steps cannot be empty";

	String SHOW_CANNOT_BE_EMPTY = "Show cannot be empty";

	String FILE_CANNOT_BE_EMPTY = "File cannot be empty";

	String FILE_NAME_CANNOT_BE_EMPTY = "File name cannot be empty";

	String ORIGINAL_FILE_NAME_CANNOT_BE_EMPTY = "Original File name cannot be empty";

	String RECIPE_CAT_NAME_CANNOT_BE_EMPTY = "Recipe category name cannot be empty";

	String RECIPE_CAT_DOES_NOT_EXIST = "Recipe category does not exist";

	String RECIPE_WITH_NAME_ALREADY_EXISTS = "Recipe with name already exists";

	String FILE_NAME_DOES_NOT_HAVE_VALID_EXTENSION = "File name does not have a valid extension";

	String COULD_NOT_SAVE_RECIPE = "Could not save recipe";

	String RECIPE_WITH_IMAGE_NAME_ALREADY_EXISTS = "Recipe with Image name already exist";

	String RECIPE_ID_CANNOT_BE_EMPTY = "Recipe id cannot be empty";

	String RECIPE_WITH_ID_DOES_NOT_EXISTS = "Recipe with Id does not exist";

	String RECIPE_WITH_NAME_ALREDY_EXISTS_FOR_DIFFRENT_RECIPE = "Recipe with name already exists for a diffrent recipe";

	String COULD_NOT_UPDATE_RECIPE = "Could not Update Recipe";

	String RECIPE_DOES_NOT_EXIST = "Recipe does not exist";

	String COULD_NOT_FETCH_RECIPE_FOR_RECIPE_NAME = "Could not fetch recipe for recipe name";

	String COULD_NOT_FETCH_RECIPES_FOR_RECIPE_CAT_NAME = "Could not fetch recipes for recipe category name";

	String COULD_NOT_FETCH_RECIPE_FOR_RECIPE_ID = "Could not fetch recipe for recipe id";

	String SAVE_OF_RECIPE_IS_SUCCESSFUL = "Save of Recipe is successful";

	String UPDATE_OF_RECIPE_IS_SUCCESSFUL = "Update of recipe is successful";

	String FETCH_OF_RECIPE_IS_SUCCESSFUL_FOR_RECIPENAME = "Fetch of recipe is successful for recipe name";

	String FETCH_OF_RECIPE_IS_SUCCESSFUL_FOR_RECIPEID = "Fetch of recipe is successful for recipe id";

	String FETCH_OF_ALL_RECIPE_IS_SUCCESSFUL = "Fetch of all recipe is successful";

	String FETCH_OF_ALL_RECIPE_FOR_RECIPE_CAT_IS_SUCCESSFUL = "Fetch of all recipe for recipe category is successful";

	String COULD_NOT_UPDATE_LIKE_FOR_RECIPE = "Could not update like for recipe";

	String LIKE_CANNOT_BE_EMPTY = "Like cannot be empty";

	String COULD_NOT_CREATE_OR_UPDATE_LIKE_FOR_RECIPE = "Could not create or update like for recipe";

	String SAVE_OF_RECIPE_LIKE_IS_SUCCESSFUL = "Save of Recipe Like is successful";

	String FETCH_OF_RECIPE_LIKE_IS_SUCCESSFUL = "Fetch of Recipe Like is successful";

	String COMMENTS_CANNOT_BE_EMPTY = "Comments cannot be empty";

	String COULD_NOT_SAVE_COMMENTS_FOR_RECIPE = "Could not save comments for recipe";

	String RECIPEID_CANNOT_BE_EMPTY = "Recipe id cannot be empty";

	String COULD_NOT_FETCH_COMMENTS_FOR_RECIPE = "Could not fetch comments for recipe";

	String SAVE_OF_RECIPE_COMMENTS_IS_SUCCESSFUL = "Save of recipe comments is successful";

	String FETCH_OF_RECIPE_COMMENTS_BY_RECIPEID_IS_SUCCESSFUL = "Fetch of recipe comments by recipe id is successful";

	String FILE_PATH_ALREADY_EXISTS_FOR_DIFFRENT_RECEPE = "File Path Already exists for diffrent recepe";

	String DELETE_OF_RECIPE_IS_SUCCESSFUL_FOR_RECIPEID = "Delete of Recipe is successful for recipe id";

	String COULD_NOT_DELETE_RECIPE_FOR_RECEPEID = "Could not delete recipe for recepe id";

	String RECEPE_ID_CANNOT_BE_EMPTY = "Recepe id cannot be empty";

	String FETCH_OF_LIKES_BY_RECEPE_ID_FAILED = "Fetch of Likes by Recepe id has failed";

	String PASSWORD_DOES_NOT_MATCH_RECORDS = "Password does not match records";

	String FETCH_OF_RECIPE_IS_SUCCESSFUL = "Fetch of Recipe is successful";
	
	

}
