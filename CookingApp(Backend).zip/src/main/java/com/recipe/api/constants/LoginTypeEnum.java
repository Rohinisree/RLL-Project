package com.recipe.api.constants;

import lombok.Getter;

@Getter
public enum LoginTypeEnum {

	ADMIN(1), USER(2);

	private final int logintype;

	LoginTypeEnum(int logintype) {
		this.logintype = logintype;
	}
}
