package com.recipe.api.response;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class AJAXResponse implements Serializable {
	private static final long serialVersionUID = 1L;
	private boolean status;
	private List<ErrorMessagesObj> errMessages;
	private Object model;
	private String sucessMsg;
	private int totalSize;
	private int total;

}
