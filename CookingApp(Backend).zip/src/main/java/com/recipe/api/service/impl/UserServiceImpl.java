package com.recipe.api.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.recipe.api.constants.LoginTypeEnum;
import com.recipe.api.constants.RecipeConstants;
import com.recipe.api.entity.UserEntity;
import com.recipe.api.exception.RecipeException;
import com.recipe.api.repository.UserRepository;
import com.recipe.api.service.inter.UserService;
import com.recipe.api.ui.ChangePasswordUI;
import com.recipe.api.ui.LoginUI;
import com.recipe.api.utils.RecipeValidationUtils;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private RecipeValidationUtils recipeValidationUtils;

	@Autowired
	private UserRepository userRepository;

	@Override
	public UserEntity createUser(UserEntity userEntity) throws RecipeException {
		UserEntity userEntitySaved = null;
		try {
			validateUserEntity(userEntity);
			userEntity.setLogintype(LoginTypeEnum.USER.getLogintype());

			Optional<UserEntity> userEntityOps = userRepository
					.findByUsername(userEntity.getUsername());
			if (userEntityOps != null && userEntityOps.isPresent()) {
				throw new RecipeException(
						RecipeConstants.DUPLICATE_USERNAME_ALREADY_EXISTS);
			}

			Optional<UserEntity> emailEntityOps = userRepository
					.findByEmail(userEntity.getEmail());
			if (emailEntityOps != null && emailEntityOps.isPresent()) {
				throw new RecipeException(RecipeConstants.EMAIL_ALREADY_EXISTS);
			}

			Optional<UserEntity> phoneNoEnOptional = userRepository
					.findByPhonenumber(userEntity.getPhonenumber());
			if (phoneNoEnOptional != null && phoneNoEnOptional.isPresent()) {
				throw new RecipeException(
						RecipeConstants.PHONENO_ALREADY_EXISTS);
			}

			userEntitySaved = userRepository.save(userEntity);
		} catch (Exception e) {
			
			if(e instanceof RecipeException){
				throw e;
			}
			
			throw new RecipeException(
					RecipeConstants.INTERNAL_ERROR_DURING_SAVE_OF_USERS_INFORMATION);
		}
		return userEntitySaved;
	}

	@Override
	public UserEntity updateUser(UserEntity userEntity) throws RecipeException {
		UserEntity userEntitySaved = null;
		try {
			validateUserEntity(userEntity);
			userEntity.setLogintype(LoginTypeEnum.USER.getLogintype());

			Optional<UserEntity> userEntityOps = userRepository
					.findByUsername(userEntity.getUsername());
			if (null == userEntityOps || !userEntityOps.isPresent()) {
				throw new RecipeException(
						RecipeConstants.USERNAME_DOES_NOT_EXISTS_TO_UPDATE);
			}

			Optional<UserEntity> emailEntityOps = userRepository
					.findByEmail(userEntity.getEmail());
			if (emailEntityOps != null && emailEntityOps.isPresent()) {

				UserEntity userEntityEmail = emailEntityOps.get();
				if (userEntityEmail != null) {
					String userNameOfEmail = userEntityEmail.getUsername();
					if (!userNameOfEmail.equals(userEntity.getUsername())) {
						throw new RecipeException(
								RecipeConstants.CANNOT_USE_THE_EMAIL);
					}
				}

			}

			Optional<UserEntity> phoneNoEnOptional = userRepository
					.findByPhonenumber(userEntity.getPhonenumber());
			if (phoneNoEnOptional != null && phoneNoEnOptional.isPresent()) {

				UserEntity userEntityPhoneNo = phoneNoEnOptional.get();
				if (userEntityPhoneNo != null) {
					String phoneNumberUser = userEntityPhoneNo.getUsername();
					if (!phoneNumberUser.equals(userEntity.getUsername())) {
						throw new RecipeException(
								RecipeConstants.CANNOT_USE_THE_PHONE_NUMBER);
					}
				}
			}

			userEntitySaved = userRepository.save(userEntity);
		} catch (Exception e) {
			if(e instanceof RecipeException){
				throw e;
			}
			throw new RecipeException(
					RecipeConstants.INTERNAL_ERROR_DURING_UPDATE_OF_USERS_INFORMATION);
		}
		return userEntitySaved;
	}

	@Override
	public UserEntity fetchUserByUserName(String userName)
			throws RecipeException {
		UserEntity userEntitySaved = null;
		try {

			if (!StringUtils.hasLength(userName)) {
				throw new RecipeException(
						RecipeConstants.USERNAME_CANNOT_BE_EMPTY);
			}

			Optional<UserEntity> userOptional = userRepository
					.findByUsername(userName);
			if (null == userOptional || !userOptional.isPresent()) {
				throw new RecipeException(
						RecipeConstants.USERNAME_DOES_NOT_EXISTS);
			}

			userEntitySaved = userOptional.get();

		} catch (Exception e) {
			if(e instanceof RecipeException){
				throw e;
			}
			throw new RecipeException(
					RecipeConstants.FETCHING_OF_USER_INFORMATION_HAS_FAILED);
		}
		return userEntitySaved;
	}

	@Override
	public UserEntity loginCustomer(LoginUI loginUI) throws RecipeException {

		UserEntity userEntitySaved = null;
		try {

			String userName = loginUI.getUsername();
			if (!StringUtils.hasLength(userName)) {
				throw new RecipeException(
						RecipeConstants.USERNAME_CANNOT_BE_EMPTY);
			}

			String authInfo = loginUI.getAuthinfo();
			if (!StringUtils.hasLength(authInfo)) {
				throw new RecipeException(
						RecipeConstants.PASSWORD_CANNOT_BE_EMPTY);
			}

			Optional<UserEntity> userOptional = userRepository
					.findByUsername(userName);

			if (null == userOptional || !userOptional.isPresent()) {
				throw new RecipeException(
						RecipeConstants.USERNAME_DOES_NOT_EXISTS);
			}

			userEntitySaved = userOptional.get();

			String authActual = userEntitySaved.getAuthinfo();
			if (!authActual.equals(authInfo)) {
				throw new RecipeException(RecipeConstants.INVALID_CREDENTIALS);
			}

		} catch (Exception e) {
			if(e instanceof RecipeException){
				throw e;
			}
			throw new RecipeException(
					RecipeConstants.FETCHING_OF_USER_INFORMATION_HAS_FAILED);
		}
		userEntitySaved.setAuthinfo(null);
		return userEntitySaved;
	}

	@Override
	public UserEntity changePassword(ChangePasswordUI changePasswordUI)
			throws RecipeException {

		UserEntity userEntitySaved = null;
		try {

			String userName = changePasswordUI.getUsername();
			if (!StringUtils.hasLength(userName)) {
				throw new RecipeException(
						RecipeConstants.USERNAME_CANNOT_BE_EMPTY);
			}

			String authInfo = changePasswordUI.getAuthinfo();
			if (!StringUtils.hasLength(authInfo)) {
				throw new RecipeException(
						RecipeConstants.NEW_PASSWORD_CANNOT_BE_EMPTY);
			}

			String oldAuthInfo = changePasswordUI.getOldauthinfo();
			if (!StringUtils.hasLength(oldAuthInfo)) {
				throw new RecipeException(
						RecipeConstants.OLD_PASSWORD_CANNOT_BE_EMPTY);
			}

			Optional<UserEntity> userOptional = userRepository
					.findByUsername(userName);

			if (null == userOptional || !userOptional.isPresent()) {
				throw new RecipeException(
						RecipeConstants.USERNAME_DOES_NOT_EXISTS);
			}

			userEntitySaved = userOptional.get();

			String authActual = userEntitySaved.getAuthinfo();
			if (!authActual.equals(oldAuthInfo)) {
				throw new RecipeException(RecipeConstants.PASSWORD_DOES_NOT_MATCH_RECORDS);
			}

			userEntitySaved.setAuthinfo(authInfo);

			userEntitySaved = userRepository.save(userEntitySaved);

		} catch (Exception e) {
			if(e instanceof RecipeException){
				throw e;
			}
			throw new RecipeException(
					RecipeConstants.COULD_NOT_UPDATE_PASSWORD_INFORMATION);
		}
		userEntitySaved.setAuthinfo(null);
		return userEntitySaved;

	}

	private void validateUserEntity(UserEntity userEntity) {
		String firstName = userEntity.getFirstname();
		if (!StringUtils.hasLength(firstName)) {
			throw new RecipeException(RecipeConstants.FIRSTNAME_CANNOT_BE_EMPTY);
		}

		String lastName = userEntity.getLastname();
		if (!StringUtils.hasLength(lastName)) {
			throw new RecipeException(RecipeConstants.LASTNAME_CANNOT_BE_EMPTY);
		}

		String userName = userEntity.getUsername();
		if (!StringUtils.hasLength(userName)) {
			throw new RecipeException(RecipeConstants.USERNAME_CANNOT_BE_EMPTY);
		}

		String authInfo = userEntity.getAuthinfo();
		if (!StringUtils.hasLength(authInfo)) {
			throw new RecipeException(RecipeConstants.PASSWORD_CANNOT_BE_EMPTY);
		}

		String email = userEntity.getEmail();
		if (!StringUtils.hasLength(email)) {
			throw new RecipeException(RecipeConstants.EMAIL_CANNOT_BE_EMPTY);
		}

		String phoneNumber = userEntity.getPhonenumber();
		if (!StringUtils.hasLength(phoneNumber)) {
			throw new RecipeException(RecipeConstants.PHONENO_CANNOT_BE_EMPTY);
		}

		int len = phoneNumber.length();
		if (len < 10 || len > 10) {
			throw new RecipeException(
					RecipeConstants.PHONENO_CANNOT_BE_LESS_THAN_10_OR_HIGHER_THAN_10);
		}

		boolean phoneNoFlag = recipeValidationUtils
				.checkPhoneNoRegex(phoneNumber);

		if (!phoneNoFlag) {
			throw new RecipeException(RecipeConstants.PHONENO_IS_INVALID);
		}
	}

}
