package com.recipe.api.service.impl;

import java.util.List;
import java.util.Optional;

import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.recipe.api.constants.RecipeConstants;
import com.recipe.api.entity.RecipeCommentsEntity;
import com.recipe.api.entity.RecipeEntity;
import com.recipe.api.entity.UserEntity;
import com.recipe.api.exception.RecipeException;
import com.recipe.api.repository.RecipeCommentsRepository;
import com.recipe.api.repository.RecipeRepository;
import com.recipe.api.repository.UserRepository;
import com.recipe.api.service.inter.RecipeCommentsService;
import com.recipe.api.ui.RecipeCommentsUIInput;

@Service
public class RecipeCommentsServiceImpl implements RecipeCommentsService {

	@Autowired
	private RecipeRepository recipeRepository;

	@Autowired
	private RecipeCommentsRepository recipeCommentsRepository;

	@Autowired
	private UserRepository userRepository;

	@Override
	public RecipeCommentsEntity createRecipeComments(
			RecipeCommentsUIInput recipeCommentsUIInput)
			throws ServiceException {

		RecipeCommentsEntity recipeCommentsEntity = null;

		try {

			Long recipeId = recipeCommentsUIInput.getRecipeid();
			if (null == recipeId) {
				throw new RecipeException(
						RecipeConstants.RECIPE_ID_CANNOT_BE_EMPTY);
			}

			String username = recipeCommentsUIInput.getUsername();
			if (!StringUtils.hasLength(username)) {
				throw new RecipeException(
						RecipeConstants.USERNAME_CANNOT_BE_EMPTY);
			}

			String comments = recipeCommentsUIInput.getComments();

			if (!StringUtils.hasLength(comments)) {
				throw new RecipeException(
						RecipeConstants.COMMENTS_CANNOT_BE_EMPTY);
			}

			Optional<RecipeEntity> recOptional = recipeRepository
					.findByRecipeid(recipeId);
			if (null == recOptional || !recOptional.isPresent()) {
				throw new RecipeException(
						RecipeConstants.RECIPE_DOES_NOT_EXIST);
			}

			Optional<UserEntity> userEntityOps = userRepository
					.findByUsername(username);
			if (null == userEntityOps || !userEntityOps.isPresent()) {
				throw new RecipeException(
						RecipeConstants.USERNAME_DOES_NOT_EXISTS_TO_UPDATE);
			}

			RecipeEntity recipeEntity = recOptional.get();
			UserEntity userEntity = userEntityOps.get();

			recipeCommentsEntity = new RecipeCommentsEntity();
			recipeCommentsEntity.setComments(comments);
			recipeCommentsEntity.setRecipeEntity(recipeEntity);
			recipeCommentsEntity.setUserEntity(userEntity);

			recipeCommentsEntity = recipeCommentsRepository
					.save(recipeCommentsEntity);

		} catch (Exception e) {

			if (e instanceof RecipeException) {
				throw e;
			}

			throw new RecipeException(
					RecipeConstants.COULD_NOT_SAVE_COMMENTS_FOR_RECIPE);
		}
		return recipeCommentsEntity;
	}

	@Override
	public List<RecipeCommentsEntity> retriveAllCommentsByRecipeId(Long recipeId)
			throws ServiceException {

		List<RecipeCommentsEntity> recipeCommentsEntityList = null;
		try {

			if (null == recipeId) {
				throw new RecipeException(
						RecipeConstants.RECIPEID_CANNOT_BE_EMPTY);
			}

			Optional<RecipeEntity> recOptional = recipeRepository
					.findByRecipeid(recipeId);

			if (null == recOptional || !recOptional.isPresent()) {
				throw new RecipeException(RecipeConstants.RECIPE_DOES_NOT_EXIST);
			}

			RecipeEntity recipeEntity = recOptional.get();

			recipeCommentsEntityList = recipeCommentsRepository
					.findAllByRecipeEntity(recipeEntity);

		} catch (Exception e) {
			if (e instanceof RecipeException) {
				throw e;
			}
			throw new RecipeException(
					RecipeConstants.COULD_NOT_FETCH_COMMENTS_FOR_RECIPE);

		}
		return recipeCommentsEntityList;
	}

}
