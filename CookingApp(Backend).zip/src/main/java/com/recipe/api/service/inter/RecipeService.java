package com.recipe.api.service.inter;

import java.util.List;

import com.recipe.api.entity.RecipeEntity;
import com.recipe.api.exception.RecipeException;
import com.recipe.api.ui.RecipeInputUI;

public interface RecipeService {

	public RecipeEntity createRecipe(RecipeInputUI recipeInputUI)
			throws RecipeException, Exception;

	public RecipeEntity updateRecipe(RecipeInputUI recipeInputUI)
			throws RecipeException;

	public RecipeEntity fetchRecipe(String recipeName) throws RecipeException;

	public RecipeEntity fetchRecipeByRecipeId(Long recipeId)
			throws RecipeException;

	public List<RecipeEntity> fetchAllRecipeList() throws RecipeException;

	public List<RecipeEntity> fetchAllRecipeListForRecipeCat(String recipeCat)
			throws RecipeException;

	public RecipeEntity deleteRecipe(Long recepeId);

	public List<RecipeEntity> fetchAllRecipeListForRecipeCatAndReceipName(
			String recipeCat, String receipName) throws RecipeException;

}
