package com.recipe.api.service.inter;

import java.util.List;

import org.hibernate.service.spi.ServiceException;

import com.recipe.api.entity.RecipeLikeEntity;
import com.recipe.api.ui.RecipeLikeUIInput;

public interface RecipeLikeService {

	public RecipeLikeEntity createRecipeLike(RecipeLikeUIInput recipeLikeUIInput)
			throws ServiceException;

	public List<RecipeLikeEntity> fetchAllRecipeLike() throws ServiceException;

	List<RecipeLikeEntity> fetchAllReceipLikeByReceiptId(Long receiptId)
			throws ServiceException;

}
