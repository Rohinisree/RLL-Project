package com.recipe.api.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.recipe.api.entity.RecipeCatEntity;
import com.recipe.api.repository.RecipeCatRepository;
import com.recipe.api.service.inter.RecipeCatService;

@Service
public class RecipeCatServiceImpl implements RecipeCatService {

	@Autowired
	private RecipeCatRepository recipeRepository;

	@Override
	public List<RecipeCatEntity> fetchAllRecipeCategories() {
		return recipeRepository.findAll();
	}

}
