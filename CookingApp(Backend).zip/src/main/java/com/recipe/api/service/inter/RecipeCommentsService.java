package com.recipe.api.service.inter;

import java.util.List;

import org.hibernate.service.spi.ServiceException;

import com.recipe.api.entity.RecipeCommentsEntity;
import com.recipe.api.ui.RecipeCommentsUIInput;

public interface RecipeCommentsService {

	public RecipeCommentsEntity createRecipeComments(
			RecipeCommentsUIInput RecipeCommentsUIInput)
			throws ServiceException;

	public List<RecipeCommentsEntity> retriveAllCommentsByRecipeId(Long recipeId)
			throws ServiceException;

}
