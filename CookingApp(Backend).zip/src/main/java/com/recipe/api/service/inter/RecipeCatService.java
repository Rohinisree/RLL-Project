package com.recipe.api.service.inter;

import java.util.List;

import com.recipe.api.entity.RecipeCatEntity;
import com.recipe.api.exception.RecipeException;

public interface RecipeCatService {

	public List<RecipeCatEntity> fetchAllRecipeCategories() throws RecipeException;

}
