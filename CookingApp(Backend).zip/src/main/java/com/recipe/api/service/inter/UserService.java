package com.recipe.api.service.inter;

import com.recipe.api.entity.UserEntity;
import com.recipe.api.exception.RecipeException;
import com.recipe.api.ui.ChangePasswordUI;
import com.recipe.api.ui.LoginUI;

public interface UserService {

	public UserEntity createUser(UserEntity userEntity) throws RecipeException;

	public UserEntity updateUser(UserEntity userEntity) throws RecipeException;

	public UserEntity fetchUserByUserName(String userName)
			throws RecipeException;

	public UserEntity loginCustomer(LoginUI loginUI) throws RecipeException;

	public UserEntity changePassword(ChangePasswordUI changePasswordUI)
			throws RecipeException;

}
