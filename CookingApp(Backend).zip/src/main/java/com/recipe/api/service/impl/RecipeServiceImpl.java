package com.recipe.api.service.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.recipe.api.constants.RecipeConstants;
import com.recipe.api.entity.RecipeCatEntity;
import com.recipe.api.entity.RecipeEntity;
import com.recipe.api.exception.RecipeException;
import com.recipe.api.repository.RecipeCatRepository;
import com.recipe.api.repository.RecipeCommentsRepository;
import com.recipe.api.repository.RecipeLikeRepository;
import com.recipe.api.repository.RecipeRepository;
import com.recipe.api.service.inter.RecipeService;
import com.recipe.api.ui.RecipeInputUI;

@Service
@Transactional(rollbackOn = Exception.class)
public class RecipeServiceImpl implements RecipeService {

	@Autowired
	private RecipeRepository recipeRepository;

	@Autowired
	private RecipeCatRepository recipeCatRepository;

	@Autowired
	private RecipeLikeRepository recipeLikeRepository;

	@Autowired
	private RecipeCommentsRepository recipeCommentsRepository;

	@Override
	public RecipeEntity createRecipe(RecipeInputUI recipeInputUI)
			throws RecipeException {
		RecipeEntity recipeEntitySaved = null;
		try {

			String recipeName = recipeInputUI.getName();
			if (!StringUtils.hasLength(recipeName)) {
				throw new RecipeException(
						RecipeConstants.RECIPE_NAME_CANNOT_BE_EMPTY);
			}

			String ingredient = recipeInputUI.getIngredient();
			if (!StringUtils.hasLength(ingredient)) {
				throw new RecipeException(
						RecipeConstants.INGREDIENT_CANNOT_BE_EMPTY);
			}

			String steps = recipeInputUI.getSteps();
			if (!StringUtils.hasLength(steps)) {
				throw new RecipeException(RecipeConstants.STEPS_CANNOT_BE_EMPTY);
			}

			Integer show = recipeInputUI.getShow();
			if (null == show || show < 0 || show > 1) {
				throw new RecipeException(RecipeConstants.SHOW_CANNOT_BE_EMPTY);
			}

			MultipartFile recipeFile = recipeInputUI.getRecipeFile();
			if (null == recipeFile) {
				throw new RecipeException(RecipeConstants.FILE_CANNOT_BE_EMPTY);
			}

			String fileName = recipeFile.getName();
			if (!StringUtils.hasLength(fileName)) {
				throw new RecipeException(
						RecipeConstants.FILE_NAME_CANNOT_BE_EMPTY);
			}

			String originalFileName = recipeFile.getOriginalFilename();
			if (!StringUtils.hasLength(originalFileName)) {
				throw new RecipeException(
						RecipeConstants.ORIGINAL_FILE_NAME_CANNOT_BE_EMPTY);
			}

			if (originalFileName != null
					&& (originalFileName.endsWith(".jpg") || originalFileName
							.endsWith(".png"))
					|| originalFileName.endsWith(".jpeg")) {
				System.out.println("Extension is valid");

			} else {
				throw new RecipeException(
						RecipeConstants.FILE_NAME_DOES_NOT_HAVE_VALID_EXTENSION);
			}

			String path = RecipeConstants.FILE_PATH + originalFileName;

			String recipeCatName = recipeInputUI.getRecipecatname();
			if (!StringUtils.hasLength(recipeCatName)) {
				throw new RecipeException(
						RecipeConstants.RECIPE_CAT_NAME_CANNOT_BE_EMPTY);
			}

			Optional<RecipeCatEntity> recipeCatEntityOps = recipeCatRepository
					.findByCatname(recipeCatName);

			if (null == recipeCatEntityOps || !recipeCatEntityOps.isPresent()) {
				throw new RecipeException(
						RecipeConstants.RECIPE_CAT_DOES_NOT_EXIST);
			}

			RecipeCatEntity recipeCatEntity = recipeCatEntityOps.get();

			Optional<RecipeEntity> recipeEntityOps = recipeRepository
					.findByName(recipeName);

			if (recipeEntityOps != null && recipeEntityOps.isPresent()) {
				throw new RecipeException(
						RecipeConstants.RECIPE_WITH_NAME_ALREADY_EXISTS);
			}

			Optional<RecipeEntity> recOptional = recipeRepository
					.findByImagepath(path);

			if (null == recOptional
					|| (recOptional != null && recOptional.isPresent())) {
				throw new RecipeException(
						RecipeConstants.RECIPE_WITH_IMAGE_NAME_ALREADY_EXISTS);
			}

			writeRecipeFileToDisk(recipeFile, path);

			RecipeEntity recipeEntityToBeSaved = populateRecipeEntityFromUI(
					recipeName, ingredient, steps, show, originalFileName,
					path, recipeCatEntity);

			recipeEntitySaved = recipeRepository.save(recipeEntityToBeSaved);

		} catch (FileNotFoundException fnfe) {

			throw new RecipeException(RecipeConstants.COULD_NOT_SAVE_RECIPE);

		} catch (IOException fnfe) {

			throw new RecipeException(RecipeConstants.COULD_NOT_SAVE_RECIPE);

		} catch (Exception e) {
			if (e instanceof RecipeException) {
				throw e;
			}
			throw new RecipeException(RecipeConstants.COULD_NOT_SAVE_RECIPE);
		}

		return recipeEntitySaved;
	}

	@Override
	public RecipeEntity updateRecipe(RecipeInputUI recipeInputUI)
			throws RecipeException {
		RecipeEntity recipeEntitySaved = null;
		try {

			Long recipeId = recipeInputUI.getRecipeid();
			if (null == recipeId) {
				throw new RecipeException(
						RecipeConstants.RECIPE_ID_CANNOT_BE_EMPTY);
			}

			String recipeName = recipeInputUI.getName();
			if (!StringUtils.hasLength(recipeName)) {
				throw new RecipeException(
						RecipeConstants.RECIPE_NAME_CANNOT_BE_EMPTY);
			}

			String ingredient = recipeInputUI.getIngredient();
			if (!StringUtils.hasLength(ingredient)) {
				throw new RecipeException(
						RecipeConstants.INGREDIENT_CANNOT_BE_EMPTY);
			}

			String steps = recipeInputUI.getSteps();
			if (!StringUtils.hasLength(steps)) {
				throw new RecipeException(RecipeConstants.STEPS_CANNOT_BE_EMPTY);
			}

			Integer show = recipeInputUI.getShow();
			if (null == show || show < 0 || show > 1) {
				throw new RecipeException(RecipeConstants.SHOW_CANNOT_BE_EMPTY);
			}

			MultipartFile recipeFile = recipeInputUI.getRecipeFile();
			if (null == recipeFile) {
				throw new RecipeException(RecipeConstants.FILE_CANNOT_BE_EMPTY);
			}

			String fileName = recipeFile.getName();
			if (!StringUtils.hasLength(fileName)) {
				throw new RecipeException(
						RecipeConstants.FILE_NAME_CANNOT_BE_EMPTY);
			}

			String originalFileName = recipeFile.getOriginalFilename();
			if (!StringUtils.hasLength(originalFileName)) {
				throw new RecipeException(
						RecipeConstants.ORIGINAL_FILE_NAME_CANNOT_BE_EMPTY);
			}

			String path = RecipeConstants.FILE_PATH + originalFileName;

			String recipeCatName = recipeInputUI.getRecipecatname();
			if (!StringUtils.hasLength(recipeCatName)) {
				throw new RecipeException(
						RecipeConstants.RECIPE_CAT_NAME_CANNOT_BE_EMPTY);
			}

			Optional<RecipeCatEntity> recipeCatEntityOps = recipeCatRepository
					.findByCatname(recipeCatName);

			if (null == recipeCatEntityOps || !recipeCatEntityOps.isPresent()) {
				throw new RecipeException(
						RecipeConstants.RECIPE_CAT_DOES_NOT_EXIST);
			}

			RecipeCatEntity recipeCatEntity = recipeCatEntityOps.get();

			Optional<RecipeEntity> recOptional =

			recipeRepository.findByRecipeid(recipeId);

			if (null == recOptional || !recOptional.isPresent()) {
				throw new RecipeException(
						RecipeConstants.RECIPE_WITH_ID_DOES_NOT_EXISTS);
			}

			Optional<RecipeEntity> recipeEntityOps = recipeRepository
					.findByName(recipeName);

			if (recipeEntityOps != null && recipeEntityOps.isPresent()) {

				RecipeEntity recipeEntityByName = recipeEntityOps.get();

				Long recipeIdExisting = recipeEntityByName.getRecipeid();

				if (recipeIdExisting.compareTo(recipeId) != 0) {
					throw new RecipeException(
							RecipeConstants.RECIPE_WITH_NAME_ALREDY_EXISTS_FOR_DIFFRENT_RECIPE);
				}

			}

			if (originalFileName != null
					&& (originalFileName.endsWith(".jpg") || originalFileName
							.endsWith(".png"))
					|| originalFileName.endsWith(".jpeg")) {
				System.out.println("Extension is valid");

			} else {
				throw new RecipeException(
						RecipeConstants.FILE_NAME_DOES_NOT_HAVE_VALID_EXTENSION);
			}

			RecipeEntity recipeEntityExisting = recOptional.get();

			Optional<RecipeEntity> recOptionalByImagePath = recipeRepository
					.findByImagepath(path);

			if (null == recOptionalByImagePath
					|| (recOptionalByImagePath != null && recOptionalByImagePath
							.isPresent())) {

				RecipeEntity recipeEntityForImage = recOptionalByImagePath
						.get();

				Long recieptIdTemp = recipeEntityForImage.getRecipeid();

				if (recieptIdTemp.compareTo(recipeId) != 0) {
					throw new RecipeException(
							RecipeConstants.FILE_PATH_ALREADY_EXISTS_FOR_DIFFRENT_RECEPE);
				}

			}

			writeRecipeFileToDisk(recipeFile, path);

			RecipeEntity recipeEntityToBeSaved = populateRecipeEntityFromUIForUpdate(
					recipeName, ingredient, steps, show, originalFileName,
					path, recipeCatEntity, recipeEntityExisting);

			recipeEntitySaved = recipeRepository.save(recipeEntityToBeSaved);

		} catch (FileNotFoundException fnfe) {

			throw new RecipeException(RecipeConstants.COULD_NOT_SAVE_RECIPE);

		} catch (IOException fnfe) {

			throw new RecipeException(RecipeConstants.COULD_NOT_SAVE_RECIPE);

		} catch (Exception e) {
			if (e instanceof RecipeException) {
				throw e;
			}
			throw new RecipeException(RecipeConstants.COULD_NOT_UPDATE_RECIPE);
		}

		return recipeEntitySaved;
	}

	@Override
	public RecipeEntity fetchRecipe(String recipeName) throws RecipeException {
		RecipeEntity recipeEntity = null;
		try {

			if (!StringUtils.hasLength(recipeName)) {
				throw new ServiceException(
						RecipeConstants.RECIPE_NAME_CANNOT_BE_EMPTY);
			}

			Optional<RecipeEntity> recipeEntityOps = recipeRepository
					.findByName(recipeName);

			if (null == recipeEntityOps || !recipeEntityOps.isPresent()) {
				throw new ServiceException(
						RecipeConstants.RECIPE_DOES_NOT_EXIST);
			}

			recipeEntity = recipeEntityOps.get();

		} catch (Exception e) {
			if (e instanceof RecipeException) {
				throw e;
			}
			throw new RecipeException(
					RecipeConstants.COULD_NOT_FETCH_RECIPE_FOR_RECIPE_NAME);
		}
		return recipeEntity;
	}

	@Override
	public RecipeEntity fetchRecipeByRecipeId(Long recipeId)
			throws RecipeException {
		RecipeEntity recipeEntity = null;
		try {

			if (null == recipeId) {
				throw new ServiceException(
						RecipeConstants.RECIPE_ID_CANNOT_BE_EMPTY);
			}

			Optional<RecipeEntity> recipeEntityOps = recipeRepository
					.findByRecipeid(recipeId);

			if (null == recipeEntityOps || !recipeEntityOps.isPresent()) {
				throw new ServiceException(
						RecipeConstants.RECIPE_DOES_NOT_EXIST);
			}

			recipeEntity = recipeEntityOps.get();

		} catch (Exception e) {
			if (e instanceof RecipeException) {
				throw e;
			}
			throw new RecipeException(
					RecipeConstants.COULD_NOT_FETCH_RECIPE_FOR_RECIPE_ID);
		}
		return recipeEntity;
	}

	@Override
	public List<RecipeEntity> fetchAllRecipeList() throws RecipeException {
		return recipeRepository.findAll();
	}

	@Override
	public List<RecipeEntity> fetchAllRecipeListForRecipeCat(String recipeCat)
			throws RecipeException {

		List<RecipeEntity> recipeEntityList = null;
		try {

			if (!StringUtils.hasLength(recipeCat)) {
				throw new ServiceException(
						RecipeConstants.RECIPE_CAT_NAME_CANNOT_BE_EMPTY);
			}

			Optional<RecipeCatEntity> recipeCatEntityOps = recipeCatRepository
					.findByCatname(recipeCat);

			if (null == recipeCatEntityOps || !recipeCatEntityOps.isPresent()) {
				throw new ServiceException(
						RecipeConstants.RECIPE_CAT_DOES_NOT_EXIST);
			}

			RecipeCatEntity recipeCatEntity = recipeCatEntityOps.get();

			recipeEntityList = recipeRepository
					.findAllByRecipeCatEntity(recipeCatEntity);

		} catch (Exception e) {
			if (e instanceof RecipeException) {
				throw e;
			}
			throw new RecipeException(
					RecipeConstants.COULD_NOT_FETCH_RECIPES_FOR_RECIPE_CAT_NAME);
		}
		return recipeEntityList;

	}

	@Override
	public RecipeEntity deleteRecipe(Long recepeId) {

		RecipeEntity recipeEntity = null;
		try {

			if (null == recepeId) {
				throw new RecipeException(
						RecipeConstants.RECEPE_ID_CANNOT_BE_EMPTY);
			}

			Optional<RecipeEntity> recOptional = recipeRepository
					.findByRecipeid(recepeId);

			if (null == recOptional || !recOptional.isPresent()) {
				throw new RecipeException(
						RecipeConstants.RECIPE_WITH_ID_DOES_NOT_EXISTS);
			}

			RecipeEntity recipeEntityActual = recOptional.get();

			recipeLikeRepository.deleteByRecipeEntity(recipeEntityActual);

			recipeCommentsRepository.deleteByRecipeEntity(recipeEntityActual);

			recipeRepository.deleteByRecipeid(recepeId);

		} catch (Exception e) {
			if (e instanceof RecipeException) {
				throw e;
			}
			throw new RecipeException(
					RecipeConstants.COULD_NOT_DELETE_RECIPE_FOR_RECEPEID);
		}
		return recipeEntity;
	}

	@Override
	public List<RecipeEntity> fetchAllRecipeListForRecipeCatAndReceipName(
			String recipeCat, String receipName) throws RecipeException {

		List<RecipeEntity> recipeEntityList = null;
		RecipeCatEntity recipeCatEntity = null;
		try {

			if (StringUtils.hasLength(recipeCat)) {

				Optional<RecipeCatEntity> recipeCatEntityOps = recipeCatRepository
						.findByCatname(recipeCat);

				if (null == recipeCatEntityOps
						|| !recipeCatEntityOps.isPresent()) {
					throw new ServiceException(
							RecipeConstants.RECIPE_CAT_DOES_NOT_EXIST);
				}

				recipeCatEntity = recipeCatEntityOps.get();
			}

			if (!StringUtils.hasLength(receipName) && recipeCatEntity != null) {
				recipeEntityList = recipeRepository
						.findAllByRecipeCatEntity(recipeCatEntity);
			} else if (StringUtils.hasLength(receipName)
					&& null == recipeCatEntity) {
				recipeEntityList = recipeRepository
						.findAllByName(receipName);

			}else if (StringUtils.hasLength(receipName)
					&& recipeCatEntity!=null) {
				recipeEntityList = recipeRepository
						.findAllByNameAndRecipeCatEntity(receipName,recipeCatEntity);

			}

		} catch (Exception e) {
			if (e instanceof RecipeException) {
				throw e;
			}
			throw new RecipeException(
					RecipeConstants.COULD_NOT_FETCH_RECIPES_FOR_RECIPE_CAT_NAME);
		}
		return recipeEntityList;
	}

	private String getFileExtension(String fileName) {
		if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0) {
			return fileName.substring(fileName.lastIndexOf(".") + 1);
		} else {
			return ""; // No extension found
		}
	}

	private RecipeEntity populateRecipeEntityFromUI(String recipeName,
			String ingredient, String steps, Integer show,
			String originalFileName, String path,
			RecipeCatEntity recipeCatEntity) {
		RecipeEntity recipeEntityToBeSaved = new RecipeEntity();
		recipeEntityToBeSaved.setImagepath(originalFileName);
		String fileExtension = getFileExtension(originalFileName);
		recipeEntityToBeSaved.setFilextension(fileExtension);
		recipeEntityToBeSaved.setIngredient(ingredient);
		recipeEntityToBeSaved.setName(recipeName.toUpperCase());
		recipeEntityToBeSaved.setShowrecipe(show);
		recipeEntityToBeSaved.setSteps(steps);
		recipeEntityToBeSaved.setRecipeCatEntity(recipeCatEntity);
		return recipeEntityToBeSaved;
	}

	private RecipeEntity populateRecipeEntityFromUIForUpdate(String recipeName,
			String ingredient, String steps, Integer show,
			String originalFileName, String path,
			RecipeCatEntity recipeCatEntity, RecipeEntity recipeEntityExisting) {
		recipeEntityExisting.setImagepath(originalFileName);
		String fileExtension = getFileExtension(originalFileName);
		recipeEntityExisting.setFilextension(fileExtension);
		recipeEntityExisting.setIngredient(ingredient);
		recipeEntityExisting.setName(recipeName.toUpperCase());
		recipeEntityExisting.setShowrecipe(show);
		recipeEntityExisting.setSteps(steps);
		recipeEntityExisting.setRecipeCatEntity(recipeCatEntity);
		return recipeEntityExisting;
	}

	private void writeRecipeFileToDisk(MultipartFile recipeFile, String path)
			throws IOException, FileNotFoundException {
		byte[] bytes = recipeFile.getBytes();
		File imageFile = new File(path);
		FileOutputStream fos = new FileOutputStream(imageFile);
		fos.write(bytes);
		fos.close();
	}

}
