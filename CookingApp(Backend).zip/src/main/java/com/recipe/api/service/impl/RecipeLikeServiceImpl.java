package com.recipe.api.service.impl;

import java.util.List;
import java.util.Optional;

import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.recipe.api.constants.RecipeConstants;
import com.recipe.api.entity.RecipeEntity;
import com.recipe.api.entity.RecipeLikeEntity;
import com.recipe.api.exception.RecipeException;
import com.recipe.api.repository.RecipeLikeRepository;
import com.recipe.api.repository.RecipeRepository;
import com.recipe.api.repository.UserRepository;
import com.recipe.api.service.inter.RecipeLikeService;
import com.recipe.api.ui.RecipeLikeUIInput;

@Service
public class RecipeLikeServiceImpl implements RecipeLikeService {

	@Autowired
	private RecipeLikeRepository recipeLikeRepository;

	@Autowired
	private RecipeRepository recipeRepository;

	@Autowired
	private UserRepository userRepository;

	@Override
	public RecipeLikeEntity createRecipeLike(RecipeLikeUIInput recipeLikeUIInput)
			throws ServiceException {

		RecipeLikeEntity recipeLikeEntity = null;
		try {

			Long recipeId = recipeLikeUIInput.getRecipeid();
			if (null == recipeId) {
				throw new ServiceException(
						RecipeConstants.RECIPE_ID_CANNOT_BE_EMPTY);
			}

			Integer like = recipeLikeUIInput.getLike();

			if (null == like) {
				throw new ServiceException(RecipeConstants.LIKE_CANNOT_BE_EMPTY);
			}

			Optional<RecipeEntity> recOptional = recipeRepository
					.findByRecipeid(recipeId);
			if (null == recOptional || !recOptional.isPresent()) {
				throw new ServiceException(
						RecipeConstants.RECIPE_DOES_NOT_EXIST);
			}

			RecipeEntity recipeEntity = recOptional.get();

			Optional<RecipeLikeEntity> recipeLikeEntityOps = recipeLikeRepository
					.findByRecipeEntity(recipeEntity);

			if (null == recipeLikeEntityOps || !recipeLikeEntityOps.isPresent()) {
				recipeLikeEntity = new RecipeLikeEntity();
				recipeLikeEntity.setLikerecipe(1);
				recipeLikeEntity.setRecipeEntity(recipeEntity);
			} else {
				recipeLikeEntity = recipeLikeEntityOps.get();
				Integer currentLikes = recipeLikeEntity.getLikerecipe();
				currentLikes = currentLikes + 1;
				recipeLikeEntity.setLikerecipe(currentLikes);
				recipeLikeEntity.setRecipeEntity(recipeEntity);
			}

			recipeLikeEntity = recipeLikeRepository.save(recipeLikeEntity);

		} catch (Exception e) {
			if (e instanceof RecipeException) {
				throw e;
			}
			throw new RecipeException(
					RecipeConstants.COULD_NOT_CREATE_OR_UPDATE_LIKE_FOR_RECIPE);
		}
		return recipeLikeEntity;

	}

	@Override
	public List<RecipeLikeEntity> fetchAllRecipeLike() throws ServiceException {
		return recipeLikeRepository.findAll();
	}

	@Override
	public List<RecipeLikeEntity> fetchAllReceipLikeByReceiptId(Long receiptId)
			throws ServiceException {

		List<RecipeLikeEntity> recipeLikeEntities = null;
		try {
			if (null == receiptId) {
				throw new RecipeException(
						RecipeConstants.RECEPE_ID_CANNOT_BE_EMPTY);
			}

			Optional<RecipeEntity> recOptional = recipeRepository
					.findByRecipeid(receiptId);
			if (null == recOptional || !recOptional.isPresent()) {
				throw new RecipeException(
						RecipeConstants.RECIPE_DOES_NOT_EXIST);
			}

			RecipeEntity recipeEntity = recOptional.get();

			recipeLikeEntities = recipeLikeRepository
					.findAllByRecipeEntity(recipeEntity);

		} catch (Exception e) {
			if (e instanceof RecipeException) {
				throw e;
			}
			throw new RecipeException(
					RecipeConstants.FETCH_OF_LIKES_BY_RECEPE_ID_FAILED);
		}
		return recipeLikeEntities;

	}

}
