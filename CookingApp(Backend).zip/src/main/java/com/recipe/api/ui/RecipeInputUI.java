package com.recipe.api.ui;

import org.springframework.web.multipart.MultipartFile;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RecipeInputUI {

	private Long recipeid;
	private String name;
	private String ingredient;
	private String steps;
	private Integer show;
	private String imagepath;
	private String recipecatname;
	private MultipartFile recipeFile;

}
