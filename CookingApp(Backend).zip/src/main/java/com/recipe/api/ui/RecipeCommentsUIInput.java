package com.recipe.api.ui;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RecipeCommentsUIInput {

	private Long recipeid;

	private String username;

	private String comments;
}
