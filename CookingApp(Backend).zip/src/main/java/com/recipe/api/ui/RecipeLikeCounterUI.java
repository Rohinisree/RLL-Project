package com.recipe.api.ui;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RecipeLikeCounterUI {
	private String recipename;
	private Integer totallikes;
}
