package com.recipe.api.ui;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RecipeSearchUI {

	private String recipeCat;
	private String receipName;

}
