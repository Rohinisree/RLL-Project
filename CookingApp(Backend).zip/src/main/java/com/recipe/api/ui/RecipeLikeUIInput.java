package com.recipe.api.ui;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RecipeLikeUIInput {
	private Long recipeid;
	private Integer like;
}
