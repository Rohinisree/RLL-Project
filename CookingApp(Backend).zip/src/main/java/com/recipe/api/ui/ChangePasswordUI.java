package com.recipe.api.ui;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChangePasswordUI extends LoginUI {

	private String oldauthinfo;

}
