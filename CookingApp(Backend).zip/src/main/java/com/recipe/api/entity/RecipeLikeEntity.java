package com.recipe.api.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "recipelike")
@Setter
@Getter
public class RecipeLikeEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long receiptlikeid;

	@ManyToOne
	@JoinColumn(name = "recipe_join_id", referencedColumnName = "recipeid", nullable = false)
	private RecipeEntity recipeEntity;

	@Column
	private Integer likerecipe;

}
