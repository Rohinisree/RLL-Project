package com.recipe.api.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "recipe")
@Setter
@Getter
public class RecipeEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long recipeid;

	@Column
	private String name;

	@Column
	private String ingredient;

	@Column
	private String steps;

	@Column
	private Integer showrecipe;

	@Column
	private String imagepath;
	
	@Column
	private String filextension;
	
	
	@ManyToOne
	@JoinColumn(name = "recipe_join_id",referencedColumnName="catname", nullable = false)
	private RecipeCatEntity recipeCatEntity;

}
