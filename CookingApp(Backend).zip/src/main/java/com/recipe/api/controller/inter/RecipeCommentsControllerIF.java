package com.recipe.api.controller.inter;

import org.hibernate.service.spi.ServiceException;
import org.springframework.http.ResponseEntity;

import com.recipe.api.response.AJAXResponse;
import com.recipe.api.ui.RecipeCommentsUIInput;

public interface RecipeCommentsControllerIF {

	public ResponseEntity<AJAXResponse> createRecipeComments(
			RecipeCommentsUIInput RecipeCommentsUIInput)
			throws ServiceException;

	public ResponseEntity<AJAXResponse> retriveAllCommentsByRecipeId(
			Long recipeId) throws ServiceException;

}
