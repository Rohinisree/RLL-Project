package com.recipe.api.controller.inter;

import org.hibernate.service.spi.ServiceException;
import org.springframework.http.ResponseEntity;

import com.recipe.api.response.AJAXResponse;
import com.recipe.api.ui.RecipeLikeUIInput;

public interface RecipeLikeControllerIF {

	public ResponseEntity<AJAXResponse> createRecipeLike(
			RecipeLikeUIInput recipeLikeUIInput) throws ServiceException;

	public ResponseEntity<AJAXResponse> fetchAllRecipeLike()
			throws ServiceException;

	public ResponseEntity<AJAXResponse> fetchAllRecipeLikeByRecipeId(
			Long recipeId) throws ServiceException;

}
