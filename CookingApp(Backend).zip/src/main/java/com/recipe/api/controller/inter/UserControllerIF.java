package com.recipe.api.controller.inter;

import org.springframework.http.ResponseEntity;

import com.recipe.api.entity.UserEntity;
import com.recipe.api.exception.RecipeException;
import com.recipe.api.response.AJAXResponse;
import com.recipe.api.ui.ChangePasswordUI;
import com.recipe.api.ui.LoginUI;

public interface UserControllerIF {

	public ResponseEntity<AJAXResponse> createUser(UserEntity userEntity)
			throws RecipeException;

	public ResponseEntity<AJAXResponse> updateUser(UserEntity userEntity)
			throws RecipeException;

	public ResponseEntity<AJAXResponse> fetchUserByUserName(String userName)
			throws RecipeException;

	public ResponseEntity<AJAXResponse> loginCustomer(LoginUI loginUI)
			throws RecipeException;

	public ResponseEntity<AJAXResponse> changePassword(
			ChangePasswordUI changePasswordUI) throws RecipeException;

}
