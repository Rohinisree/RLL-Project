package com.recipe.api.controller.impl;

import java.util.List;

import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.recipe.api.constants.RecipeConstants;
import com.recipe.api.controller.BaseController;
import com.recipe.api.controller.inter.RecipeCommentsControllerIF;
import com.recipe.api.entity.RecipeCommentsEntity;
import com.recipe.api.response.AJAXResponse;
import com.recipe.api.service.inter.RecipeCommentsService;
import com.recipe.api.ui.RecipeCommentsUIInput;

@RestController
public class RecipeCommentsControllerImpl extends BaseController implements
		RecipeCommentsControllerIF {

	@Autowired
	private RecipeCommentsService recipeCommentsService;

	@PostMapping("/recipecomments")
	@Override
	public ResponseEntity<AJAXResponse> createRecipeComments(
			@RequestBody RecipeCommentsUIInput recipeCommentsUIInput)
			throws ServiceException {

		RecipeCommentsEntity recipeEntitySaved = recipeCommentsService
				.createRecipeComments(recipeCommentsUIInput);

		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.SAVE_OF_RECIPE_COMMENTS_IS_SUCCESSFUL,
				recipeEntitySaved);
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);

	}

	@GetMapping("/recipecomments/byRecipeId/{recipeId}")
	@Override
	public ResponseEntity<AJAXResponse> retriveAllCommentsByRecipeId(
			@PathVariable("recipeId") Long recipeId) throws ServiceException {

		List<RecipeCommentsEntity> recipeLikeEntityList = recipeCommentsService
				.retriveAllCommentsByRecipeId(recipeId);

		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.FETCH_OF_RECIPE_COMMENTS_BY_RECIPEID_IS_SUCCESSFUL,
				recipeLikeEntityList);

		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);
	}

}
