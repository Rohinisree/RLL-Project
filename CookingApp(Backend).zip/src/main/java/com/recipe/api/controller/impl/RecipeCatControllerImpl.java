package com.recipe.api.controller.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.recipe.api.constants.RecipeConstants;
import com.recipe.api.controller.BaseController;
import com.recipe.api.controller.inter.RecipeCatControllerIF;
import com.recipe.api.entity.RecipeCatEntity;
import com.recipe.api.exception.RecipeException;
import com.recipe.api.response.AJAXResponse;
import com.recipe.api.service.inter.RecipeCatService;

@RestController
public class RecipeCatControllerImpl extends BaseController implements
		RecipeCatControllerIF {

	@Autowired
	private RecipeCatService recipeCatService;

	@GetMapping("/recipecat")
	public ResponseEntity<AJAXResponse> fetchAllRecipeCategories()
			throws RecipeException {

		List<RecipeCatEntity> recipeCatList = recipeCatService
				.fetchAllRecipeCategories();

		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.FETCH_OF_RECIPE_CAT_IS_SUCCESSFUL,
				recipeCatList);
		
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);

	}
}
