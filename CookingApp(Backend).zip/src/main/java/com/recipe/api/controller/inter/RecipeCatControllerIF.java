package com.recipe.api.controller.inter;

import org.springframework.http.ResponseEntity;

import com.recipe.api.exception.RecipeException;
import com.recipe.api.response.AJAXResponse;

public interface RecipeCatControllerIF {

	public ResponseEntity<AJAXResponse> fetchAllRecipeCategories() throws RecipeException;

}
