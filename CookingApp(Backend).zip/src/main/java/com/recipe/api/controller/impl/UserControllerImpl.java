package com.recipe.api.controller.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.recipe.api.constants.RecipeConstants;
import com.recipe.api.controller.BaseController;
import com.recipe.api.controller.inter.UserControllerIF;
import com.recipe.api.entity.UserEntity;
import com.recipe.api.exception.RecipeException;
import com.recipe.api.response.AJAXResponse;
import com.recipe.api.service.inter.UserService;
import com.recipe.api.ui.ChangePasswordUI;
import com.recipe.api.ui.LoginUI;

@RestController
public class UserControllerImpl extends BaseController implements
		UserControllerIF {

	@Autowired
	private UserService userService;

	@Override
	@PostMapping("/user")
	public ResponseEntity<AJAXResponse> createUser(
			@RequestBody UserEntity userEntity) throws RecipeException {
		UserEntity userEntitySaved = userService.createUser(userEntity);
		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.SAVE_OF_USER_IS_SUCCESSFUL, userEntitySaved);
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);

	}

	@Override
	@PutMapping("/user")
	public ResponseEntity<AJAXResponse> updateUser(
			@RequestBody UserEntity userEntity) throws RecipeException {
		UserEntity userEntitySaved = userService.updateUser(userEntity);
		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.UPDATE_OF_USER_IS_SUCCESSFUL, userEntitySaved);
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);
	}

	@Override
	@GetMapping("/user/fetchByUserName/{userName}")
	public ResponseEntity<AJAXResponse> fetchUserByUserName(
			@PathVariable("userName") String userName) throws RecipeException {
		UserEntity userEntitySaved = userService.fetchUserByUserName(userName);
		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.FETCH_OF_USER_IS_SUCCESSFUL, userEntitySaved);
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);

	}

	@Override
	@PostMapping("/login")
	public ResponseEntity<AJAXResponse> loginCustomer(
			@RequestBody LoginUI loginUI) throws RecipeException {
		UserEntity userEntitySaved = userService.loginCustomer(loginUI);
		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.LOGIN_IS_SUCCESSFUL, userEntitySaved);
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);
	}

	@Override
	@PostMapping("/changePassword")
	public ResponseEntity<AJAXResponse> changePassword(
			@RequestBody ChangePasswordUI changePasswordUI)
			throws RecipeException {
		UserEntity userEntitySaved = userService
				.changePassword(changePasswordUI);
		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.CHANGE_PASSWORD_IS_SUCCESSFUL, userEntitySaved);
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);
	}

}
