package com.recipe.api.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.recipe.api.response.AJAXResponse;
import com.recipe.api.response.ErrorMessagesObj;

@Component
public class BaseController {

	public AJAXResponse generateErrorMessageBasedResponse(
			AJAXResponse ajaxResponse, String message) {
		List<ErrorMessagesObj> errMessages = new ArrayList<ErrorMessagesObj>();
		ErrorMessagesObj errorMessagesObj = new ErrorMessagesObj();
		errorMessagesObj.setErrMessage(message);
		errMessages.add(errorMessagesObj);
		ajaxResponse.setErrMessages(errMessages);
		ajaxResponse.setStatus(false);
		return ajaxResponse;
	}

	public AJAXResponse generateSuccessResponse(String sucessMsg,
			Object sucessModel) {

		AJAXResponse ajaxResponse = new AJAXResponse();
		ajaxResponse.setStatus(true);
		ajaxResponse.setModel(sucessModel);
		ajaxResponse.setSucessMsg(sucessMsg);

		return ajaxResponse;

	}

}
