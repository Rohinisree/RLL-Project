package com.recipe.api.controller.impl;

import java.util.List;

import org.hibernate.service.spi.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.recipe.api.constants.RecipeConstants;
import com.recipe.api.controller.BaseController;
import com.recipe.api.controller.inter.RecipeLikeControllerIF;
import com.recipe.api.entity.RecipeLikeEntity;
import com.recipe.api.response.AJAXResponse;
import com.recipe.api.service.inter.RecipeLikeService;
import com.recipe.api.ui.RecipeLikeUIInput;

@RestController
public class RecipeLikeControllerImpl extends BaseController implements
		RecipeLikeControllerIF {

	@Autowired
	private RecipeLikeService recipeLikeService;

	@Override
	@PostMapping("/recipelike")
	public ResponseEntity<AJAXResponse> createRecipeLike(
			@RequestBody RecipeLikeUIInput recipeLikeUIInput)
			throws ServiceException {

		RecipeLikeEntity recipeEntitySaved = recipeLikeService
				.createRecipeLike(recipeLikeUIInput);
		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.SAVE_OF_RECIPE_LIKE_IS_SUCCESSFUL,
				recipeEntitySaved);
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);
	}

	@Override
	@GetMapping("/recipelike")
	public ResponseEntity<AJAXResponse> fetchAllRecipeLike()
			throws ServiceException {
		List<RecipeLikeEntity> recipeLikeEntityList = recipeLikeService
				.fetchAllRecipeLike();

		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.FETCH_OF_RECIPE_LIKE_IS_SUCCESSFUL,
				recipeLikeEntityList);

		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);
	}

	@Override
	@GetMapping("/recipelike/byReceipId/{recipeId}")
	public ResponseEntity<AJAXResponse> fetchAllRecipeLikeByRecipeId(
			@PathVariable("recipeId") Long recipeId) throws ServiceException {

		List<RecipeLikeEntity> recipeLikeEntityList = recipeLikeService
				.fetchAllReceipLikeByReceiptId(recipeId);

		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.FETCH_OF_RECIPE_LIKE_IS_SUCCESSFUL,
				recipeLikeEntityList);

		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);
	}

}
