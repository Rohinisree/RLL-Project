package com.recipe.api.controller.inter;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

import com.recipe.api.exception.RecipeException;
import com.recipe.api.response.AJAXResponse;
import com.recipe.api.ui.RecipeInputUI;
import com.recipe.api.ui.RecipeSearchUI;

public interface RecipeControllerIF {

	public ResponseEntity<AJAXResponse> createRecipe(RecipeInputUI recipeInputUI)
			throws RecipeException, Exception;

	public ResponseEntity<AJAXResponse> updateRecipe(RecipeInputUI recipeInputUI)
			throws RecipeException;

	public ResponseEntity<AJAXResponse> fetchRecipe(String recipeName)
			throws RecipeException;

	public ResponseEntity<AJAXResponse> fetchRecipeByRecipeId(Long recipeId)
			throws RecipeException;

	public ResponseEntity<AJAXResponse> fetchAllRecipeList()
			throws RecipeException;

	public ResponseEntity<AJAXResponse> fetchAllRecipeListForRecipeCat(
			String recipeCat) throws RecipeException;

	public ResponseEntity<AJAXResponse> deleteRecipe(Long recepeId);

	public ResponseEntity<AJAXResponse> fetchAllRecipeListForCriteria(
			@RequestBody RecipeSearchUI recipeSearchUI) throws RecipeException;

}
