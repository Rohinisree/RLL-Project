package com.recipe.api.controller.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.recipe.api.constants.RecipeConstants;
import com.recipe.api.controller.BaseController;
import com.recipe.api.controller.inter.RecipeControllerIF;
import com.recipe.api.entity.RecipeEntity;
import com.recipe.api.exception.RecipeException;
import com.recipe.api.response.AJAXResponse;
import com.recipe.api.service.inter.RecipeService;
import com.recipe.api.ui.RecipeInputUI;
import com.recipe.api.ui.RecipeSearchUI;

@RestController
public class RecipeControllerImpl extends BaseController implements
		RecipeControllerIF {

	@Autowired
	private RecipeService recipeServiceIF;

	@Override
	@PostMapping("/recipe")
	public ResponseEntity<AJAXResponse> createRecipe(
			@ModelAttribute RecipeInputUI recipeInputUI) throws Exception {
		RecipeEntity recipeEntitySaved = null;
		try {
			recipeEntitySaved = recipeServiceIF.createRecipe(recipeInputUI);
		} catch (Exception e) {

			if (e instanceof RecipeException) {
				throw e;
			}

		}
		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.SAVE_OF_RECIPE_IS_SUCCESSFUL, recipeEntitySaved);
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);

	}

	@Override
	@PostMapping("/recipe/update")
	public ResponseEntity<AJAXResponse> updateRecipe(
			@ModelAttribute RecipeInputUI recipeInputUI) throws RecipeException {
		RecipeEntity recipeEntitySaved = recipeServiceIF
				.updateRecipe(recipeInputUI);
		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.UPDATE_OF_RECIPE_IS_SUCCESSFUL,
				recipeEntitySaved);
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);
	}

	@Override
	@GetMapping("/recipe/fetchByRecipeName/{recipeName}")
	public ResponseEntity<AJAXResponse> fetchRecipe(
			@PathVariable("recipeName") String recipeName)
			throws RecipeException {
		RecipeEntity recipeEntitySaved = recipeServiceIF
				.fetchRecipe(recipeName);
		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.FETCH_OF_RECIPE_IS_SUCCESSFUL_FOR_RECIPENAME,
				recipeEntitySaved);
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);
	}

	@Override
	@GetMapping("/recipe/fetchByRecipeId/{recipeId}")
	public ResponseEntity<AJAXResponse> fetchRecipeByRecipeId(
			@PathVariable("recipeId") Long recipeId) throws RecipeException {
		RecipeEntity recipeEntitySaved = recipeServiceIF
				.fetchRecipeByRecipeId(recipeId);
		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.FETCH_OF_RECIPE_IS_SUCCESSFUL_FOR_RECIPEID,
				recipeEntitySaved);
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);
	}

	@Override
	@GetMapping("/recipe/fetchAllRecipe")
	public ResponseEntity<AJAXResponse> fetchAllRecipeList()
			throws RecipeException {
		List<RecipeEntity> recipeEntityList = recipeServiceIF
				.fetchAllRecipeList();
		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.FETCH_OF_ALL_RECIPE_IS_SUCCESSFUL,
				recipeEntityList);
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);
	}

	@Override
	@GetMapping("/recipe/fetchAllRecipeByCatName/{recipeCat}")
	public ResponseEntity<AJAXResponse> fetchAllRecipeListForRecipeCat(
			@PathVariable("recipeCat") String recipeCat) throws RecipeException {
		List<RecipeEntity> recipeEntityList = recipeServiceIF
				.fetchAllRecipeListForRecipeCat(recipeCat);
		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.FETCH_OF_ALL_RECIPE_FOR_RECIPE_CAT_IS_SUCCESSFUL,
				recipeEntityList);
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);
	}

	@Override
	@DeleteMapping("/delete/byRecepeId/{recepeId}")
	public ResponseEntity<AJAXResponse> deleteRecipe(
			@PathVariable("recepeId") Long recepeId) {
		RecipeEntity recipeEntitySaved = recipeServiceIF.deleteRecipe(recepeId);
		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.DELETE_OF_RECIPE_IS_SUCCESSFUL_FOR_RECIPEID,
				recipeEntitySaved);
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);
	}

	@Override
	@PostMapping("/recipe/fetchAllByCriteria")
	public ResponseEntity<AJAXResponse> fetchAllRecipeListForCriteria(
			@RequestBody RecipeSearchUI recipeSearchUI) throws RecipeException {
		List<RecipeEntity> recipeEntitySavedList = null;
		try {
			recipeEntitySavedList = recipeServiceIF
					.fetchAllRecipeListForRecipeCatAndReceipName(
							recipeSearchUI.getRecipeCat(),
							recipeSearchUI.getReceipName());
		} catch (Exception e) {

			if (e instanceof RecipeException) {
				throw e;
			}

		}
		AJAXResponse ajaxResponse = generateSuccessResponse(
				RecipeConstants.FETCH_OF_RECIPE_IS_SUCCESSFUL, recipeEntitySavedList);
		return ResponseEntity.status(HttpStatus.OK).body(ajaxResponse);
	}

}
