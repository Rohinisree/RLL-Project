Ext.require(['Ext.grid.*', 'Ext.data.*', 'Ext.form.*', 'Ext.layout.container.Column', 'Ext.tab.Panel']);

Ext.Loader.setConfig({
	enabled: true
});
Ext.tip.QuickTipManager.init();
var detailStore;
var hideConfirmationMsg;
var showConfirmationMsg;
/* Hide the Confirmation Message */
hideConfirmationMsg = function () {
	var confMsgDiv = Ext.get('confirmationMessage');
	confMsgDiv.dom.innerHTML = "";
	confMsgDiv.dom.style.display = 'none';
}
/* Show Confirmation Message */
showConfirmationMsg = function (msg) {
	var confMsgDiv = Ext.get('confirmationMessage');
	confMsgDiv.dom.innerHTML = msg;
	confMsgDiv.dom.style.display = 'inline-block';
}

function retriveAllCustomersForCriteria(selectedData,urlLink){
			 let store = Ext.getCmp('detailsTableGrid').getStore();
				store.removeAll();
				store.load({
				url: urlLink,
				params: {
					phoneno: selectedData.phoneno
				}
		 });
 }
 function getSelectedInformation() {
			let selectedInfo = {};
			selectedInfo.phoneno = Ext.getCmp('phoneno')
				.getValue();
			return selectedInfo;
		 }
 function searchByCriteria(){
    let selectedInfo = getSelectedInformation();
    let urlLink2 = contextPath +
        '/managecontactfilter';
    retriveAllCustomersForCriteria(selectedInfo, urlLink2);
 }


var salesColumns = [
	{
		header: 'Phone No',
		dataIndex: 'phoneNo',
		sortable: true,
		width: 100,
	    renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},
	{
		header: 'Name',
		dataIndex: 'name',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},
	{
		header: 'Email',
		dataIndex: 'email',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'Message',
		dataIndex: 'message',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'Company Name',
		dataIndex: 'companyname',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	}
];


var webSiteStore;
Ext.onReady(function () {

	var loadMask = new Ext.LoadMask(Ext.getBody(), {
		msg: "Loading"
	});
	loadMask.show();

	Ext.define('salesGridModel', {
		extend: 'Ext.data.Model',
		fields: [
			{
				name: 'appName',
				mapping: 'appName',
				type: 'string'
			},{
				name: 'phoneNo',
				mapping: 'phoneNo',
				type: 'string'
			},
			{
				name: 'name',
				mapping: 'name',
				type: 'string'
			},
			{
				name: 'email',
				mapping: 'email',
				type: 'string'
			},
			{
				name: 'message',
				mapping: 'message',
				type: 'string'
			},
			{
				name: 'companyname',
				mapping: 'companyname',
				type: 'string'
			}
			]
	});

	detailStore = Ext.create('Ext.data.Store', {
		id: 'detailStoreId',
		name: 'detailStoreName',
		model: 'salesGridModel',
		pageSize: 15,
		autoLoad: {
			start: 0,
			limit: 15
		},
		proxy: {
			type: 'ajax',
			url: contextPath + '/getAllContactInfoWithSession',
			extraParams: {
			},
			actionMethods: {
				read: 'GET'
			},
			reader: {
				type: 'json',
				root: 'model',
				totalProperty: 'totalSize',
				
			}
		},
		listeners: {
			'load': function (store, records) {

				loadMask.hide();
			}
		},
		autoLoad: true
	});

	var detailsTableGrid = Ext.create('Ext.grid.Panel', {
		title: 'View All Contacts',
		forceFit: true,
		id: 'detailsTableGrid',
		store: detailStore,
		columns: salesColumns,
		autoFit: true,
		autoscroll: true,
		width: 1200,
		height: 400,
		stripRows: true,
		selType: 'rowmodel',
		renderTo: 'customercontainer',
		collapsible: true,
		overflowY: 'auto',
		bbar: Ext.create('Ext.PagingToolbar', {
			store: detailStore,
			displayInfo: true,
			displayMsg: 'Displaying Contacts {0} - {1} of {2}',
			emptyMsg: "No Contacts to display",
			inputItemWidth: 35
		})
	});
	
	var contentPanel = Ext.create(
        'Ext.form.Panel', {
            title: 'Search Customer By Phone Nos',
            width: 800,
            height: 100,
            defaults: {
                labelAlign: 'top',
                width: 'auto',
				padding: '10px 10px 10px 10px',
				margin: '5px 5px 5px 5px'
            },
            layout: {
                type: 'table',
                columns: 3
            },
            items: [{
                    xtype: 'textfield',
                    fieldLabel: 'Enter the Phone No',
                    msgTarget: 'under',
                    id: 'phoneno',
                    name: 'phoneno'
                },
                {
                    xtype: 'button',
                    text: 'Search Contacts',
                    id: 'searchcustomerbtn',
                    handler: function(store, btn, args) {
                        hideConfirmationMsg();
                        searchByCriteria();
                    }
                }, {
                    xtype: 'button',
                    text: 'Reset',
                    id: 'reset',
                    handler: function(store, btn, args) {
                        hideConfirmationMsg();
                        Ext.getCmp('phoneno').setValue('');
                        searchByCriteria();
                    }
                }
            ],
            renderTo: 'searchcustomer'
        });

	hideConfirmationMsg();
});