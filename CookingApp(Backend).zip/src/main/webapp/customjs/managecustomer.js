Ext.require(['Ext.grid.*', 'Ext.data.*', 'Ext.form.*', 'Ext.layout.container.Column', 'Ext.tab.Panel']);

Ext.Loader.setConfig({
	enabled: true
});
Ext.tip.QuickTipManager.init();
var detailStore;
var hideConfirmationMsg;
var showConfirmationMsg;
/* Hide the Confirmation Message */
hideConfirmationMsg = function () {
	var confMsgDiv = Ext.get('confirmationMessage');
	confMsgDiv.dom.innerHTML = "";
	confMsgDiv.dom.style.display = 'none';
}
/* Show Confirmation Message */
showConfirmationMsg = function (msg) {
	var confMsgDiv = Ext.get('confirmationMessage');
	confMsgDiv.dom.innerHTML = msg;
	confMsgDiv.dom.style.display = 'inline-block';
}

function retriveAllCustomersForCriteria(selectedData,urlLink){
			 let store = Ext.getCmp('detailsTableGrid').getStore();
				store.removeAll();
				store.load({
				url: urlLink,
				params: {
					phoneno: selectedData.phoneno
				}
		 });
 }
 function getSelectedInformation() {
			let selectedInfo = {};
			selectedInfo.phoneno = Ext.getCmp('phoneno')
				.getValue();
			return selectedInfo;
		 }
 function searchByCriteria(){
    let selectedInfo = getSelectedInformation();
    let urlLink2 = contextPath +
        '/managecustomerfilter';
    retriveAllCustomersForCriteria(selectedInfo, urlLink2);
 }


var salesColumns = [
	{
		header: 'Phone No',
		dataIndex: 'phoneno',
		sortable: true,
		width: 100,
	    renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},
	{
		header: 'Customer Name',
		dataIndex: 'customername',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},
	{
		header: 'Email',
		dataIndex: 'email',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'State',
		dataIndex: 'state',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'City',
		dataIndex: 'city',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'Country',
		dataIndex: 'country',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'Address',
		dataIndex: 'address',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'User Name',
		dataIndex: 'userName',
		sortable: true,
		hidden:true,
		width: 100,
		renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'User Name',
		dataIndex: 'userName',
		sortable: true,
		width: 100,
		hidden:true,
	    renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	}
];


var webSiteStore;
Ext.onReady(function () {

	var loadMask = new Ext.LoadMask(Ext.getBody(), {
		msg: "Loading"
	});
	loadMask.show();

	Ext.define('salesGridModel', {
		extend: 'Ext.data.Model',
		fields: [{
				name: 'customerid',
				mapping: 'customerid',
				type: 'int'
			},
			{
				name: 'appName',
				mapping: 'appName',
				type: 'string'
			},{
				name: 'phoneno',
				mapping: 'phoneno',
				type: 'string'
			},{
				name: 'updatedby',
				mapping: 'updatedby',
				type: 'string'
			},
			{
				name: 'customername',
				mapping: 'customername',
				type: 'string'
			},
			{
				name: 'email',
				mapping: 'email',
				type: 'string'
			},
			{
				name: 'state',
				mapping: 'state',
				type: 'string'
			},
			{
				name: 'city',
				mapping: 'city',
				type: 'string'
			},{
				name: 'country',
				mapping: 'country',
				type: 'string'
			},{
				name: 'state',
				mapping: 'state',
				type: 'string'
			},{
				name: 'address',
				mapping: 'address',
				type: 'string'
			},{
				name: 'userName',
				mapping: 'userName',
				type: 'string'
			}
		]
	});

	detailStore = Ext.create('Ext.data.Store', {
		id: 'detailStoreId',
		name: 'detailStoreName',
		model: 'salesGridModel',
		pageSize: 15,
		autoLoad: {
			start: 0,
			limit: 15
		},
		proxy: {
			type: 'ajax',
			url: contextPath + '/managecustomer',
			extraParams: {
			},
			actionMethods: {
				read: 'GET'
			},
			reader: {
				type: 'json',
				root: 'model',
				totalProperty: 'totalSize',
				
			}
		},
		listeners: {
			'load': function (store, records) {

				loadMask.hide();
			}
		},
		autoLoad: true
	});

	var detailsTableGrid = Ext.create('Ext.grid.Panel', {
		title: 'View All Customer',
		forceFit: true,
		id: 'detailsTableGrid',
		store: detailStore,
		columns: salesColumns,
		autoFit: true,
		autoscroll: true,
		width: 1200,
		height: 400,
		stripRows: true,
		selType: 'rowmodel',
		renderTo: 'customercontainer',
		plugins: {
	        ptype: 'rowediting',
	        clicksToEdit: 1
	    },
		collapsible: true,
		overflowY: 'auto',
		bbar: Ext.create('Ext.PagingToolbar', {
			store: detailStore,
			displayInfo: true,
			displayMsg: 'Displaying Customers {0} - {1} of {2}',
			emptyMsg: "No Customers to display",
			inputItemWidth: 35
		})
	});
	
	
	
	detailsTableGrid.on('edit', function (editor, e) { 
		
		let rowNum=e.rowIdx;
		let  recordObj=e.record;
		let customerid=recordObj.data.customerid;
		let customername=recordObj.data.customername;
		let email = recordObj.data.email;
		let state = recordObj.data.state;
		let country =  recordObj.data.country;
		let city = recordObj.data.city;
		let address = recordObj.data.address;
	    let phoneno = recordObj.data.phoneno;
	
		let docInfo= {} ;
		docInfo.customerid=customerid;
		docInfo.email=email;
		docInfo.customername=customername;
		docInfo.state=state;
		docInfo.country=country;
		docInfo.city=city;
		docInfo.address=address;
		docInfo.phoneno=phoneno;
		
		updateCustomerInfo(docInfo);	
	});
	
	
	function updateCustomerInfo(docInfo)
	{
		var	urlLink=contextPath+'/managecustomer';
		Ext.Ajax.request({	
				method: 'POST',
				processData: false,
				contentType:'application/json',
				jsonData: Ext.encode(docInfo),
				url:urlLink, 
				success: function(result) {
				var rsResponse = Ext.decode(result.responseText);
				if(rsResponse.sucessMsg){
					var message=rsResponse.sucessMsg;
					if(message)
					{
						hideConfirmationMsg();
						showConfirmationMsg(message);
						detailStore.commitChanges();
					}
					}else{
						var messageToBeShown = rsResponse.errMessages[0].errMessage;
		                showConfirmationMsg(messageToBeShown);
					}
				},
			failure : function(data) {
			
			}
			});
	}
	
	var contentPanel = Ext
    .create(
        'Ext.form.Panel', {
            title: 'Search Customer By Phone Nos',
            width: 800,
            height: 100,
            defaults: {
                labelAlign: 'top',
                width: 'auto',
				padding: '10px 10px 10px 10px',
				margin: '5px 5px 5px 5px'
            },
            layout: {
                type: 'table',
                columns: 3
            },
            items: [{
                    xtype: 'textfield',
                    fieldLabel: 'Enter the Phone No',
                    msgTarget: 'under',
                    id: 'phoneno',
                    name: 'phoneno'
                },
                {
                    xtype: 'button',
                    text: 'Search Customer',
                    id: 'searchcustomerbtn',
                    handler: function(store, btn, args) {
                        hideConfirmationMsg();
                        searchByCriteria();
                    }
                }, {
                    xtype: 'button',
                    text: 'Reset',
                    id: 'reset',
                    handler: function(store, btn, args) {
                        hideConfirmationMsg();
                        Ext.getCmp('phoneno').setValue('');
                        searchByCriteria();

                    }
                }
            ],
            renderTo: 'searchcustomer'
        });
	
	
	hideConfirmationMsg();
});