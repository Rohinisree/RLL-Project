Ext.require(['Ext.grid.*', 'Ext.data.*', 'Ext.form.*', 'Ext.layout.container.Column', 'Ext.tab.Panel']);

Ext.Loader.setConfig({
	enabled: true
});
Ext.tip.QuickTipManager.init();
var detailStore;
var hideConfirmationMsg;
var showConfirmationMsg;
/* Hide the Confirmation Message */
hideConfirmationMsg = function () {
	var confMsgDiv = Ext.get('confirmationMessage');
	confMsgDiv.dom.innerHTML = "";
	confMsgDiv.dom.style.display = 'none';
}
/* Show Confirmation Message */
showConfirmationMsg = function (msg) {
	var confMsgDiv = Ext.get('confirmationMessage');
	confMsgDiv.dom.innerHTML = msg;
	confMsgDiv.dom.style.display = 'inline-block';
}

function retriveAllCustomersForCriteria(selectedData,urlLink){
			 let store = Ext.getCmp('detailsTableGrid').getStore();
				store.removeAll();
				store.load({
				url: urlLink,
				params: {
					phoneno: selectedData.phoneno
				}
		 });
 }
 function getSelectedInformation() {
			let selectedInfo = {};
			selectedInfo.phoneno = Ext.getCmp('phoneno')
				.getValue();
			return selectedInfo;
		 }
 function searchByCriteria(){
    let selectedInfo = getSelectedInformation();
    let urlLink2 = contextPath +
        '/managecandidatefilter';
    retriveAllCustomersForCriteria(selectedInfo, urlLink2);
 }


var salesColumns = [
	{
		header: 'First Name',
		dataIndex: 'firstname',
		sortable: true,
		width: 100,
	    renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},
	{
		header: 'Last Name',
		dataIndex: 'lastname',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},
	{
		header: 'Phone Number',
		dataIndex: 'phoneno',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'Email Address',
		dataIndex: 'emailAddress',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'State',
		dataIndex: 'state',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'City',
		dataIndex: 'city',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'Zip Code',
		dataIndex: 'zipcode',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'Highest Qualification',
		dataIndex: 'highestqualification',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'Discard',
		dataIndex: 'discard',
		sortable: true,
		hidden:true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'Interviewed',
		dataIndex: 'interviewed',
		sortable: true,
		hidden:true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'Skill Set',
		dataIndex: 'skillset',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	},{
		header: 'Certifications',
		dataIndex: 'additionalcertifications',
		sortable: true,
		width: 100,
		editor: 'textfield',
        renderer : function(value, metadata, record, rowIndex, colIndex, store) {
         					metadata.tdAttr = 'data-qtip="' + value + '"';
         					return value;
        }
	}
];


var webSiteStore;
Ext.onReady(function () {

	var loadMask = new Ext.LoadMask(Ext.getBody(), {
		msg: "Loading"
	});
	loadMask.show();

	Ext.define('salesGridModel', {
		extend: 'Ext.data.Model',
		fields: [{
				name: 'jobcandidatestoreid',
				mapping: 'jobcandidatestoreid',
				type: 'int'
			},{
				name: 'firstname',
				mapping: 'firstname',
				type: 'string'
			},{
				name: 'lastname',
				mapping: 'lastname',
				type: 'string'
			},{
				name: 'phoneno',
				mapping: 'phoneno',
				type: 'string'
			},{
				name: 'emailAddress',
				mapping: 'emailAddress',
				type: 'string'
			},{
				name: 'state',
				mapping: 'state',
				type: 'string'
			},{
				name: 'city',
				mapping: 'city',
				type: 'string'
			},
			{
				name: 'zipcode',
				mapping: 'zipcode',
				type: 'string'
			},
			
			{
				name: 'appName',
				mapping: 'appName',
				type: 'string'
			},{
				name: 'highestqualification',
				mapping: 'highestqualification',
				type: 'string'
			},{
				name: 'discard',
				mapping: 'discard',
				type: 'boolean'
			},
			{
				name: 'interviewed',
				mapping: 'interviewed',
				type: 'boolean'
			},{
				name: 'skillset',
				mapping: 'skillset',
				type: 'string'
			},
			{
				name: 'additionalcertifications',
				mapping: 'additionalcertifications',
				type: 'string'
			}
			]
	});

	detailStore = Ext.create('Ext.data.Store', {
		id: 'detailStoreId',
		name: 'detailStoreName',
		model: 'salesGridModel',
		pageSize: 15,
		autoLoad: {
			start: 0,
			limit: 15
		},
		proxy: {
			type: 'ajax',
			url: contextPath + '/getAllJobStoreInfoWithSession',
			extraParams: {
			},
			actionMethods: {
				read: 'GET'
			},
			reader: {
				type: 'json',
				root: 'model',
				totalProperty: 'totalSize',
				
			}
		},
		listeners: {
			'load': function (store, records) {

				loadMask.hide();
			}
		},
		autoLoad: true
	});

	var detailsTableGrid = Ext.create('Ext.grid.Panel', {
		title: 'View All Candidates Information',
		forceFit: true,
		id: 'detailsTableGrid',
		store: detailStore,
		columns: salesColumns,
		autoFit: true,
		autoscroll: true,
		width: 1200,
		height: 400,
		stripRows: true,
		selType: 'rowmodel',
		renderTo: 'customercontainer',
		collapsible: true,
		overflowY: 'auto',
		bbar: Ext.create('Ext.PagingToolbar', {
			store: detailStore,
			displayInfo: true,
			displayMsg: 'Displaying Candidates {0} - {1} of {2}',
			emptyMsg: "No Candidates to display",
			inputItemWidth: 35
		})
	});
	
	var contentPanel = Ext.create(
        'Ext.form.Panel', {
            title: 'Search Candidate By Phone Nos',
            width: 800,
            height: 100,
            defaults: {
                labelAlign: 'top',
                width: 'auto',
				padding: '10px 10px 10px 10px',
				margin: '5px 5px 5px 5px'
            },
            layout: {
                type: 'table',
                columns: 3
            },
            items: [{
                    xtype: 'textfield',
                    fieldLabel: 'Enter the Phone No',
                    msgTarget: 'under',
                    id: 'phoneno',
                    name: 'phoneno'
                },
                {
                    xtype: 'button',
                    text: 'Search Candidates',
                    id: 'searchcustomerbtn',
                    handler: function(store, btn, args) {
                        hideConfirmationMsg();
                        searchByCriteria();
                    }
                }, {
                    xtype: 'button',
                    text: 'Reset',
                    id: 'reset',
                    handler: function(store, btn, args) {
                        hideConfirmationMsg();
                        Ext.getCmp('phoneno').setValue('');
                        searchByCriteria();
                    }
                }
            ],
            renderTo: 'searchcustomer'
        });

	hideConfirmationMsg();
});