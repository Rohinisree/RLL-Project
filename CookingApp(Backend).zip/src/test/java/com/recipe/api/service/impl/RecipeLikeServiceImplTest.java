package com.recipe.api.service.impl;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.hibernate.service.spi.ServiceException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.recipe.api.entity.RecipeEntity;
import com.recipe.api.entity.RecipeLikeEntity;
import com.recipe.api.exception.RecipeException;
import com.recipe.api.repository.RecipeLikeRepository;
import com.recipe.api.repository.RecipeRepository;
import com.recipe.api.ui.RecipeLikeUIInput;

public class RecipeLikeServiceImplTest {

    @Mock
    private RecipeLikeRepository recipeLikeRepository;

    @Mock
    private RecipeRepository recipeRepository;

    @InjectMocks
    private RecipeLikeServiceImpl recipeLikeService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testCreateRecipeLike_Success() throws ServiceException {
        // Arrange
        RecipeLikeUIInput input = new RecipeLikeUIInput();
        input.setRecipeid(1L);
        input.setLike(1);

        RecipeEntity recipeEntity = new RecipeEntity();
        recipeEntity.setRecipeid(1L);

        Optional<RecipeEntity> optionalRecipe = Optional.of(recipeEntity);
        when(recipeRepository.findByRecipeid(1L)).thenReturn(optionalRecipe);

        RecipeLikeEntity savedRecipeLikeEntity = new RecipeLikeEntity();
        savedRecipeLikeEntity.setReceiptlikeid(1L);
        savedRecipeLikeEntity.setLikerecipe(1);
        savedRecipeLikeEntity.setRecipeEntity(recipeEntity);
        when(recipeLikeRepository.save(any(RecipeLikeEntity.class))).thenReturn(savedRecipeLikeEntity);

        // Act
        RecipeLikeEntity result = recipeLikeService.createRecipeLike(input);

        // Assert
        assertNotNull(result);
        assertEquals(savedRecipeLikeEntity.getReceiptlikeid(), result.getReceiptlikeid());
        assertEquals(savedRecipeLikeEntity.getLikerecipe(), result.getLikerecipe());
        assertEquals(savedRecipeLikeEntity.getRecipeEntity(), result.getRecipeEntity());
    }

    @Test(expected = RecipeException.class)
    public void testCreateRecipeLike_RecipeIdNull() throws ServiceException {
        // Arrange
        RecipeLikeUIInput input = new RecipeLikeUIInput();

        // Act
        recipeLikeService.createRecipeLike(input);

        // Should throw ServiceException
    }

    // Write similar test cases for other scenarios

    @Test
    public void testFetchAllRecipeLike() throws ServiceException {
        // Arrange
        List<RecipeLikeEntity> expectedLikes = new ArrayList<>();
        when(recipeLikeRepository.findAll()).thenReturn(expectedLikes);

        // Act
        List<RecipeLikeEntity> result = recipeLikeService.fetchAllRecipeLike();

        // Assert
        assertEquals(expectedLikes, result);
    }

    @Test
    public void testFetchAllRecipeLikeByReceiptId() throws ServiceException {
        // Arrange
        Long receiptId = 1L;
        RecipeEntity recipeEntity = new RecipeEntity();
        recipeEntity.setRecipeid(receiptId);

        List<RecipeLikeEntity> expectedLikes = new ArrayList<>();
        when(recipeRepository.findByRecipeid(receiptId)).thenReturn(Optional.of(recipeEntity));
        when(recipeLikeRepository.findAllByRecipeEntity(recipeEntity)).thenReturn(expectedLikes);

        // Act
        List<RecipeLikeEntity> result = recipeLikeService.fetchAllReceipLikeByReceiptId(receiptId);

        // Assert
        assertEquals(expectedLikes, result);
    }
}
