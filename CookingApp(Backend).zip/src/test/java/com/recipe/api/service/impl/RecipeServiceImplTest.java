package com.recipe.api.service.impl;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.multipart.MultipartFile;

import com.recipe.api.entity.RecipeCatEntity;
import com.recipe.api.entity.RecipeEntity;
import com.recipe.api.exception.RecipeException;
import com.recipe.api.repository.RecipeCatRepository;
import com.recipe.api.repository.RecipeCommentsRepository;
import com.recipe.api.repository.RecipeLikeRepository;
import com.recipe.api.repository.RecipeRepository;
import com.recipe.api.ui.RecipeInputUI;

public class RecipeServiceImplTest {

    @Mock
    private RecipeRepository recipeRepository;

    @Mock
    private RecipeCatRepository recipeCatRepository;

    @Mock
    private RecipeLikeRepository recipeLikeRepository;

    @Mock
    private RecipeCommentsRepository recipeCommentsRepository;

    @InjectMocks
    private RecipeServiceImpl recipeService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    @Test(expected=RecipeException.class)
    public void testCreateRecipe_Success() throws RecipeException {
        RecipeInputUI input = new RecipeInputUI();
        input.setName("DOSA");
        input.setIngredient("SALT");
        input.setImagepath("C:\\tes");
        input.setRecipecatname("VEG");
        
        MultipartFile multipartFileMock = mock(MultipartFile.class);
        when(multipartFileMock.getName()).thenReturn("testFile");
        when(multipartFileMock.getOriginalFilename()).thenReturn("test.jpg");
        
        input.setRecipeFile(multipartFileMock);
        input.setRecipeid(1L);
        input.setShow(1);
        input.setSteps("These are steps");
        
        when(recipeCatRepository.findByCatname(input.getRecipecatname()))
            .thenReturn(Optional.of(new RecipeCatEntity()));

        when(recipeRepository.findByName(input.getName()))
            .thenReturn(Optional.empty());
        when(recipeRepository.findByImagepath(anyString()))
            .thenReturn(Optional.empty());
        when(recipeRepository.save(any(RecipeEntity.class)))
            .thenReturn(new RecipeEntity());
        RecipeEntity result = recipeService.createRecipe(input);
        assertNotNull(result);
    }

    @Test
    public void testFetchAllRecipeList() throws RecipeException {
        List<RecipeEntity> expectedRecipes = new ArrayList<>();
             when(recipeRepository.findAll()).thenReturn(expectedRecipes);
        List<RecipeEntity> result = recipeService.fetchAllRecipeList();
        assertNotNull(result);
        assertEquals(expectedRecipes.size(), result.size());
    }
}
