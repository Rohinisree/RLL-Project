package com.recipe.api.service.impl;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.recipe.api.entity.RecipeCatEntity;
import com.recipe.api.repository.RecipeCatRepository;

public class RecipeCatServiceImplTest {

    @Mock
    private RecipeCatRepository recipeRepository;

    @InjectMocks
    private RecipeCatServiceImpl recipeCatService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testFetchAllRecipeCategories() {
        RecipeCatEntity recipe1 = new RecipeCatEntity();
        recipe1.setCatname("VEG");
        RecipeCatEntity recipe2 = new RecipeCatEntity();
        recipe2.setCatname("NONVEG");
        List<RecipeCatEntity> expectedRecipes = Arrays.asList(recipe1, recipe2);
        when(recipeRepository.findAll()).thenReturn(expectedRecipes);
        List<RecipeCatEntity> actualRecipes = recipeCatService.fetchAllRecipeCategories();
        assertRecipeCatEntityList(expectedRecipes, actualRecipes);

        verify(recipeRepository, times(1)).findAll();
    }

	private void assertRecipeCatEntityList(
			List<RecipeCatEntity> expectedRecipes,
			List<RecipeCatEntity> actualRecipes) {
		assertNotNull(actualRecipes);
        assertEquals(expectedRecipes.size(), actualRecipes.size());
        for (int i = 0; i < expectedRecipes.size(); i++) {
            assertEquals(expectedRecipes.get(i), actualRecipes.get(i));
        }
	}
}
