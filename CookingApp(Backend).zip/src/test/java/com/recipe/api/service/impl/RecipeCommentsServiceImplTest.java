package com.recipe.api.service.impl;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.recipe.api.entity.RecipeCommentsEntity;
import com.recipe.api.entity.RecipeEntity;
import com.recipe.api.entity.UserEntity;
import com.recipe.api.exception.RecipeException;
import com.recipe.api.repository.RecipeCommentsRepository;
import com.recipe.api.repository.RecipeRepository;
import com.recipe.api.repository.UserRepository;
import com.recipe.api.ui.RecipeCommentsUIInput;

public class RecipeCommentsServiceImplTest {

	@Mock
	private RecipeRepository recipeRepository;

	@Mock
	private RecipeCommentsRepository recipeCommentsRepository;

	@Mock
	private UserRepository userRepository;

	@InjectMocks
	private RecipeCommentsServiceImpl recipeCommentsService;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testCreateRecipeComments_Success() throws RecipeException {
		// Arrange
		RecipeCommentsUIInput input = new RecipeCommentsUIInput();
		input.setRecipeid(1L);
		input.setUsername("testUser");
		input.setComments("Test comment");

		RecipeEntity recipeEntity = new RecipeEntity();
		recipeEntity.setRecipeid(1L);

		Optional<RecipeEntity> optionalRecipe = Optional.of(recipeEntity);
		when(recipeRepository.findByRecipeid(1L)).thenReturn(optionalRecipe);

		UserEntity userEntity = new UserEntity();
		userEntity.setUsername("testUser");
		Optional<UserEntity> optionalUser = Optional.of(userEntity);
		when(userRepository.findByUsername("testUser"))
				.thenReturn(optionalUser);

		RecipeCommentsEntity savedRecipeCommentsEntity = new RecipeCommentsEntity();
		savedRecipeCommentsEntity.setRecipecommentid(1L);
		savedRecipeCommentsEntity.setComments("Test comment");
		savedRecipeCommentsEntity.setRecipeEntity(recipeEntity);
		savedRecipeCommentsEntity.setUserEntity(userEntity);
		when(recipeCommentsRepository.save(any(RecipeCommentsEntity.class)))
				.thenReturn(savedRecipeCommentsEntity);

		// Act
		RecipeCommentsEntity result = recipeCommentsService
				.createRecipeComments(input);

		// Assert
		assertNotNull(result);
		assertEquals(savedRecipeCommentsEntity.getRecipecommentid(),
				result.getRecipecommentid());
		assertEquals(savedRecipeCommentsEntity.getComments(),
				result.getComments());
		assertEquals(savedRecipeCommentsEntity.getRecipeEntity(),
				result.getRecipeEntity());
		assertEquals(savedRecipeCommentsEntity.getUserEntity(),
				result.getUserEntity());
	}

	@Test(expected = RecipeException.class)
	public void testCreateRecipeComments_InvalidRecipeId()
			throws RecipeException {
		// Arrange
		RecipeCommentsUIInput input = new RecipeCommentsUIInput();
		input.setRecipeid(null);
		input.setUsername("testUser");
		input.setComments("Test comment");

		// Act
		recipeCommentsService.createRecipeComments(input);
	}

	@Test
	public void testRetrieveAllCommentsByRecipeId() throws RecipeException {
		// Arrange
		Long recipeId = 1L;
		RecipeEntity recipeEntity = new RecipeEntity();
		recipeEntity.setRecipeid(recipeId);

		List<RecipeCommentsEntity> expectedComments = new ArrayList<>();
		when(recipeRepository.findByRecipeid(recipeId)).thenReturn(
				Optional.of(recipeEntity));
		when(recipeCommentsRepository.findAllByRecipeEntity(recipeEntity))
				.thenReturn(expectedComments);

		// Act
		List<RecipeCommentsEntity> result = recipeCommentsService
				.retriveAllCommentsByRecipeId(recipeId);

		// Assert
		assertEquals(expectedComments, result);
	}
}
